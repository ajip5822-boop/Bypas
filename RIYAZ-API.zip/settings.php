<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'conn.php';

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Get current user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle username change
if (isset($_POST['change_username'])) {
    $new_username = trim($_POST['new_username']);
    
    // Check if username already exists
    $check = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
    $check->bind_param("si", $new_username, $user_id);
    $check->execute();
    $check_result = $check->get_result();
    
    if ($check_result->num_rows > 0) {
        $error = "Username already exists!";
    } elseif (strlen($new_username) < 3) {
        $error = "Username must be at least 3 characters!";
    } else {
        $update = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
        $update->bind_param("si", $new_username, $user_id);
        if ($update->execute()) {
            $_SESSION['username'] = $new_username;
            $message = "Username updated successfully!";
            $user['username'] = $new_username;
        } else {
            $error = "Failed to update username!";
        }
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verify current password
    if (!password_verify($current_password, $user['password'])) {
        $error = "Current password is incorrect!";
    } elseif (strlen($new_password) < 6) {
        $error = "New password must be at least 6 characters!";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match!";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $update->bind_param("si", $hashed_password, $user_id);
        if ($update->execute()) {
            $message = "Password updated successfully!";
        } else {
            $error = "Failed to update password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings • VBOX</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #020617, #0f172a, #1e3a8a, #312e81);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            min-height: 100vh;
            color: #fff;
            overflow-x: hidden;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        #particles-js {
            position: fixed;
            inset: 0;
            z-index: -1;
        }

        /* GLASS EFFECT */
        .glass, .glass-card, .modal-content, .sidebar-btn, header, .settings-card {
            background: rgba(15, 23, 42, 0.7);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 22px;
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
        }

        /* RGB Animation for Headings */
        @keyframes rgbHeading {
            0% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
            17% { color: #ff9933; text-shadow: 0 0 10px #ff8800; }
            33% { color: #ffff33; text-shadow: 0 0 10px #ffff00; }
            50% { color: #33ff33; text-shadow: 0 0 10px #00ff00; }
            67% { color: #33ccff; text-shadow: 0 0 10px #0099ff; }
            83% { color: #9933ff; text-shadow: 0 0 10px #8800ff; }
            100% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
        }

        .rgb-heading {
            animation: rgbHeading 3s linear infinite;
            font-weight: 700;
        }

        /* HEADER */
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 60px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
            background: rgba(15, 23, 42, 0.8);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 0;
        }

        .menu-btn {
            font-size: 1.5rem;
            cursor: pointer;
            color: #ffd700;
            transition: all 0.3s ease;
        }
        .menu-btn:hover {
            transform: scale(1.1) rotate(90deg);
            color: #22d3ee;
        }

        .user-badge {
            background: rgba(255, 215, 0, 0.15);
            padding: 8px 20px;
            border-radius: 50px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid rgba(255, 215, 0, 0.3);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .user-badge:hover {
            background: rgba(255, 215, 0, 0.25);
            transform: scale(1.05);
            border-color: #ffd700;
        }
        .user-badge i {
            color: #ffd700;
            font-size: 1.1rem;
        }
        .user-badge span {
            font-weight: 600;
            color: #fff;
        }

        /* SIDEBAR */
        #sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            width: 260px;
            height: 100%;
            padding-top: 80px;
            transition: 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1100;
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border-right: 1px solid rgba(255, 255, 255, 0.18);
        }
        #sidebar.active {
            left: 0;
        }

        /* SIDEBAR LOGO */
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
            padding: 0 15px;
        }
        .logo-container {
            width: 100px;
            height: 100px;
            margin: 0 auto 15px;
            position: relative;
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        .logo-glow {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
            border-radius: 50%;
            padding: 3px;
            animation: rotate 4s linear infinite;
        }
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .logo-inner {
            width: 100%;
            height: 100%;
            background: #1a1f2e;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: #ffd700;
            animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(255, 215, 0, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0); }
        }
        .logo-text {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: rgbText 3s linear infinite;
        }
        @keyframes rgbText {
            0% { filter: hue-rotate(0deg); }
            50% { filter: hue-rotate(180deg); }
            100% { filter: hue-rotate(360deg); }
        }
        .admin-badge {
            background: linear-gradient(135deg, #ffd700, #ffa500);
            color: #000;
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-block;
            margin-top: 5px;
            animation: glow 2s ease-in-out infinite;
        }
        @keyframes glow {
            0% { box-shadow: 0 0 5px #ffd700; }
            50% { box-shadow: 0 0 20px #ffd700; }
            100% { box-shadow: 0 0 5px #ffd700; }
        }

        .sidebar-btn {
            width: 90%;
            margin: 8px auto;
            padding: 12px 16px;
            border-radius: 16px;
            border: none;
            background: rgba(255, 255, 255, 0.08);
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .sidebar-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }
        .sidebar-btn:hover::before {
            left: 100%;
        }
        .sidebar-btn i {
            width: 22px;
            text-align: center;
            color: #ffd700;
            transition: all 0.3s ease;
        }
        .sidebar-btn:hover {
            background: linear-gradient(135deg, #2563eb, #22d3ee);
            transform: translateX(8px);
            box-shadow: 0 5px 15px rgba(37, 99, 235, 0.3);
        }
        .sidebar-btn:hover i {
            color: #fff;
            transform: scale(1.1);
        }

        /* OVERLAY */
        #overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            opacity: 0;
            pointer-events: none;
            transition: 0.3s;
            z-index: 1050;
        }
        #overlay.active {
            opacity: 1;
            pointer-events: auto;
        }

        /* MAIN CONTENT */
        .main {
            padding: 90px 24px 24px;
            max-width: 1200px;
            margin: 0 auto;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* SETTINGS CARD */
        .settings-card {
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 30px;
        }

        .settings-title {
            font-size: 2rem;
            font-weight: 700;
            text-align: center;
            margin: 20px 0 40px;
            animation: rgbHeading 3s linear infinite;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: 600;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            background: rgba(0, 0, 0, 0.5);
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
            color: #fff;
            outline: none;
        }

        .btn-save {
            background: linear-gradient(135deg, #ffd700, #ffa500);
            color: #000;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .btn-save:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
        }

        .alert {
            border-radius: 16px;
            padding: 15px 20px;
            margin-bottom: 20px;
            border: none;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        .alert-success {
            background: rgba(34, 197, 94, 0.2);
            color: #4ade80;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .current-info {
            background: rgba(255, 215, 0, 0.05);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .info-icon {
            width: 50px;
            height: 50px;
            background: rgba(255, 215, 0, 0.1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #ffd700;
        }
        .info-text {
            flex: 1;
        }
        .info-label {
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.5);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .info-value {
            font-size: 1.2rem;
            font-weight: 600;
            color: #ffd700;
        }

        /* Divider */
        .divider {
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
            margin: 30px 0;
            position: relative;
        }
        .divider::before {
            content: 'OR';
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background: #1a1f2e;
            padding: 0 15px;
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.8rem;
        }

        /* SCROLLBAR */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #ffd700, #22d3ee);
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #22d3ee, #ffd700);
        }

        @media (max-width: 768px) {
            .main {
                padding: 80px 15px 15px;
            }
            .settings-title {
                font-size: 1.5rem;
            }
            .current-info {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<!-- Particles -->
<div id="particles-js"></div>

<!-- Header -->
<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <h4 class="mb-0 rgb-heading">Settings</h4>
    </div>
    
    <!-- User Badge -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
    </div>
</header>

<!-- Overlay -->
<div id="overlay" onclick="toggleSidebar()"></div>

<!-- SIDEBAR WITH LOGO -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                <!-- Image Logo -->
                <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                     style="width:100px; height:100px; border-radius:50%;">
            </div>
        </div>
    </div>

        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($_SESSION['username']) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-edit"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<!-- Main Content -->
<div class="main">
    
    <!-- Settings Title -->
    <div class="settings-title">
        <i class="fas fa-cog me-3"></i>ACCOUNT SETTINGS
    </div>

    <!-- Messages -->
    <?php if (!empty($message)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i> <?= $message ?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i> <?= $error ?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Current Info -->
    <div class="current-info glass">
        <div class="info-icon">
            <i class="fas fa-user"></i>
        </div>
        <div class="info-text">
            <div class="info-label">Current Username</div>
            <div class="info-value"><?= htmlspecialchars($user['username']) ?></div>
        </div>
        <div class="info-icon">
            <i class="fas fa-envelope"></i>
        </div>
        <div class="info-text">
            <div class="info-label">Email</div>
            <div class="info-value"><?= htmlspecialchars($user['email'] ?? 'Not set') ?></div>
        </div>
    </div>

    <!-- Change Username Form -->
    <div class="settings-card glass">
        <h5 class="rgb-heading mb-4"><i class="fas fa-user-edit me-2"></i>Change Username</h5>
        
        <form method="POST">
            <div class="form-group">
                <label class="form-label">New Username</label>
                <input type="text" name="new_username" class="form-control" placeholder="Enter new username" required minlength="3">
            </div>
            <button type="submit" name="change_username" class="btn-save">
                <i class="fas fa-save me-2"></i>Update Username
            </button>
        </form>
    </div>

    <!-- Divider -->
    <div class="divider"></div>

    <!-- Change Password Form -->
    <div class="settings-card glass">
        <h5 class="rgb-heading mb-4"><i class="fas fa-lock me-2"></i>Change Password</h5>
        
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Current Password</label>
                <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Enter new password (min 6 characters)" required minlength="6">
            </div>
            
            <div class="form-group">
                <label class="form-label">Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required minlength="6">
            </div>
            
            <button type="submit" name="change_password" class="btn-save">
                <i class="fas fa-save me-2"></i>Update Password
            </button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>

<script>
// Particles
particlesJS("particles-js", {
    particles: {
        number: { value: 60 },
        color: { value: "#ffffff" },
        opacity: { value: 0.3 },
        size: { value: 2 },
        move: { 
            enable: true,
            speed: 0.8,
            direction: "bottom",
            random: true
        }
    }
});

// Sidebar
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('active');
}

// Close overlay
document.getElementById('overlay').onclick = function() {
    document.getElementById('sidebar').classList.remove('active');
    document.getElementById('overlay').classList.remove('active');
};

// Close sidebar when clicking outside
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.querySelector('.menu-btn');
    const overlay = document.getElementById('overlay');
    
    if (!sidebar.contains(e.target) && !menuBtn.contains(e.target) && sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
});
</script>

</body>
</html>