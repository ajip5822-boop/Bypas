<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
include 'conn.php';

$current_user = $_SESSION['username'];
$current_user_id = $_SESSION['user_id'] ?? 0;

// Get current user's role
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$current_user_id'");
$current_user_data = mysqli_fetch_assoc($user_query);
$user_role = $current_user_data['role'] ?? 'user';
$is_owner = ($user_role == 'owner');
$is_admin = ($user_role == 'admin' || $user_role == 'owner');

/* ========= GENERATE ========= */
if (isset($_POST['generate'])) {
    $newCode = strtoupper(bin2hex(random_bytes(4)));
    $assigned_to = $_POST['assigned_to'] ?? 'user';
    $created_by = $current_user_id;
    
    // Check if columns exist, if not use basic insert
    $columns_check = mysqli_query($conn, "SHOW COLUMNS FROM referral_codes LIKE 'assigned_to'");
    if (mysqli_num_rows($columns_check) > 0) {
        // New structure with all columns
        $stmt = $conn->prepare("INSERT INTO referral_codes (code, assigned_to, created_by) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $newCode, $assigned_to, $created_by);
    } else {
        // Old structure - basic insert
        $stmt = $conn->prepare("INSERT INTO referral_codes (code) VALUES (?)");
        $stmt->bind_param("s", $newCode);
    }
    
    if ($stmt->execute()) {
        $_SESSION['success_msg'] = "Referral code generated successfully!";
    } else {
        $_SESSION['error_msg'] = "Error: " . $conn->error;
    }
    
    header("Location: manage_referrals.php");
    exit();
}

/* ========= EDIT ========= */
if (isset($_POST['edit_code'])) {
    $id = (int)$_POST['code_id'];
    $assigned_to = $_POST['assigned_to'];
    $status = (int)$_POST['status'];
    
    // Check if columns exist
    $columns_check = mysqli_query($conn, "SHOW COLUMNS FROM referral_codes LIKE 'assigned_to'");
    if (mysqli_num_rows($columns_check) > 0) {
        $stmt = $conn->prepare("UPDATE referral_codes SET assigned_to = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sii", $assigned_to, $status, $id);
        $stmt->execute();
    }
    
    header("Location: manage_referrals.php");
    exit();
}

/* ========= DELETE ========= */
if (isset($_POST['delete_id'])) {
    $id = (int)$_POST['delete_id'];
    $stmt = $conn->prepare("DELETE FROM referral_codes WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_referrals.php");
    exit();
}

/* ========= FETCH ========= */
// Check if used_by column exists to join with users
$used_by_exists = mysqli_query($conn, "SHOW COLUMNS FROM referral_codes LIKE 'used_by'");
if (mysqli_num_rows($used_by_exists) > 0) {
    $referrals = mysqli_query($conn, "SELECT r.*, u.username as used_by_username 
                                      FROM referral_codes r 
                                      LEFT JOIN users u ON r.used_by = u.id 
                                      ORDER BY r.id DESC");
} else {
    $referrals = mysqli_query($conn, "SELECT * FROM referral_codes ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>VBOX – Referral Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: 'Montserrat', sans-serif;
    background: linear-gradient(120deg, #020617, #0f172a, #1e3a8a, #312e81);
    background-size: 400% 400%;
    animation: bg 18s ease infinite;
    color: #fff;
    overflow-x: hidden;
    min-height: 100vh;
}
@keyframes bg {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

#particles-js {
    position: fixed;
    inset: 0;
    z-index: -2;
}

/* GLASS EFFECT */
.glass, .glass-card, .modal-content, .sidebar-btn, header, .table-container {
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 22px;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
}

/* HEADER */
header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 60px;
    padding: 0 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 1000;
    background: rgba(15, 23, 42, 0.8);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 0;
}
.menu-btn {
    font-size: 1.5rem;
    cursor: pointer;
    color: #ffd700;
    transition: all 0.3s ease;
}
.menu-btn:hover {
    transform: scale(1.1) rotate(90deg);
    color: #22d3ee;
}
.user-badge {
    background: rgba(255, 215, 0, 0.15);
    padding: 8px 20px;
    border-radius: 50px;
    display: flex;
    align-items: center;
    gap: 10px;
    border: 1px solid rgba(255, 215, 0, 0.3);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    transition: all 0.3s ease;
    cursor: pointer;
}
.user-badge:hover {
    background: rgba(255, 215, 0, 0.25);
    transform: scale(1.05);
    border-color: #ffd700;
}
.user-badge i {
    color: #ffd700;
    font-size: 1.1rem;
}
.user-badge span {
    font-weight: 600;
    color: #fff;
}

/* SIDEBAR */
#sidebar {
    position: fixed;
    top: 0;
    left: -280px;
    height: 100%;
    width: 260px;
    padding-top: 80px;
    transition: 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1100;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
}
#sidebar.active {
    left: 0;
}

/* SIDEBAR LOGO */
.sidebar-logo {
    text-align: center;
    margin-bottom: 30px;
    padding: 0 15px;
}
.logo-container {
    width: 100px;
    height: 100px;
    margin: 0 auto 15px;
    position: relative;
    animation: float 3s ease-in-out infinite;
}
@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
}
.logo-glow {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
    border-radius: 50%;
    padding: 3px;
    animation: rotate 4s linear infinite;
}
@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.logo-inner {
    width: 100%;
    height: 100%;
    background: #1a1f2e;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: #ffd700;
    animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.7); }
    70% { box-shadow: 0 0 0 15px rgba(255, 215, 0, 0); }
    100% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0); }
}
.logo-text {
    font-size: 1.3rem;
    font-weight: 700;
    background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: rgbText 3s linear infinite;
}
@keyframes rgbText {
    0% { filter: hue-rotate(0deg); }
    50% { filter: hue-rotate(180deg); }
    100% { filter: hue-rotate(360deg); }
}
.admin-badge {
    background: linear-gradient(135deg, #ffd700, #ffa500);
    color: #000;
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
    margin-top: 5px;
    animation: glow 2s ease-in-out infinite;
}
@keyframes glow {
    0% { box-shadow: 0 0 5px #ffd700; }
    50% { box-shadow: 0 0 20px #ffd700; }
    100% { box-shadow: 0 0 5px #ffd700; }
}

.sidebar-btn {
    width: 90%;
    margin: 8px auto;
    padding: 12px 16px;
    border-radius: 16px;
    border: none;
    background: rgba(255, 255, 255, 0.08);
    color: #fff;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}
.sidebar-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
}
.sidebar-btn:hover::before {
    left: 100%;
}
.sidebar-btn i {
    width: 22px;
    text-align: center;
    color: #ffd700;
    transition: all 0.3s ease;
}
.sidebar-btn:hover {
    background: linear-gradient(135deg, #2563eb, #22d3ee);
    transform: translateX(8px);
    box-shadow: 0 5px 15px rgba(37, 99, 235, 0.3);
}
.sidebar-btn:hover i {
    color: #fff;
    transform: scale(1.1);
}

/* OVERLAY */
#overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    opacity: 0;
    pointer-events: none;
    transition: 0.3s;
    z-index: 1050;
}
#overlay.active {
    opacity: 1;
    pointer-events: auto;
}

/* MAIN CONTENT */
.main {
    padding: 90px 24px 24px;
    max-width: 1200px;
    margin: 0 auto;
    animation: fadeIn 0.5s ease;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ALERT MESSAGES */
.alert {
    border-radius: 16px;
    padding: 15px 20px;
    margin-bottom: 20px;
    border: none;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}
.alert-success {
    background: rgba(34, 197, 94, 0.2);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.3);
}
.alert-danger {
    background: rgba(239, 68, 68, 0.2);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.3);
}

/* RGB TITLE */
.rgb-title {
    font-size: 2rem;
    font-weight: 700;
    text-align: center;
    margin: 20px 0 30px;
    animation: rgbTitle 3s linear infinite;
    text-transform: uppercase;
    letter-spacing: 2px;
}
@keyframes rgbTitle {
    0% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
    17% { color: #ff9933; text-shadow: 0 0 10px #ff8800; }
    33% { color: #ffff33; text-shadow: 0 0 10px #ffff00; }
    50% { color: #33ff33; text-shadow: 0 0 10px #00ff00; }
    67% { color: #33ccff; text-shadow: 0 0 10px #0099ff; }
    83% { color: #9933ff; text-shadow: 0 0 10px #8800ff; }
    100% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
}

/* GENERATE CARD */
.generate-card {
    background: rgba(255, 215, 0, 0.05);
    border: 1px solid rgba(255, 215, 0, 0.2);
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 30px;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

.premium-select {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 215, 0, 0.3);
    color: #fff;
    border-radius: 12px;
    padding: 10px 15px;
    width: 100%;
    margin: 10px 0;
}

.premium-select option {
    background: #1a1f2e;
    color: #fff;
}

.btn-generate {
    background: linear-gradient(135deg, #ffd700, #ffa500);
    color: #000;
    border: none;
    padding: 12px 30px;
    border-radius: 50px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-generate:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
}

/* TABLE CONTAINER */
.table-container {
    background: rgba(15, 23, 42, 0.5);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 30px;
    padding: 25px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
    overflow-x: auto;
}

.premium-table {
    width: 100%;
    border-collapse: collapse;
    color: #fff;
}

.premium-table th {
    background: rgba(255, 215, 0, 0.1);
    color: #ffd700;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 1px;
    padding: 16px 12px;
    border: none;
    position: relative;
    overflow: hidden;
}

.premium-table th i {
    margin-right: 8px;
    color: #ffd700;
}

.premium-table td {
    padding: 14px 12px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    vertical-align: middle;
}

.premium-table tbody tr {
    transition: all 0.3s ease;
}

.premium-table tbody tr:hover {
    background: rgba(255, 255, 255, 0.05);
    transform: scale(1.01);
}

/* BADGES */
.role-badge {
    padding: 4px 12px;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.role-owner {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
    border: 1px solid rgba(255, 215, 0, 0.3);
}

.role-admin {
    background: rgba(59, 130, 246, 0.2);
    color: #93c5fd;
    border: 1px solid rgba(59, 130, 246, 0.3);
}

.role-user {
    background: rgba(107, 114, 128, 0.2);
    color: #d1d5db;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.status-badge {
    padding: 4px 12px;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-available {
    background: rgba(34, 197, 94, 0.2);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.3);
}

.status-used {
    background: rgba(107, 114, 128, 0.2);
    color: #9ca3af;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

/* ACTION BUTTONS */
.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: center;
}

.btn-glass {
    padding: 6px 14px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: all 0.3s ease;
    cursor: pointer;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.btn-copy {
    background: rgba(34, 197, 94, 0.15);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.3);
}

.btn-copy:hover {
    background: rgba(34, 197, 94, 0.3);
    transform: scale(1.05);
    color: white;
}

.btn-edit {
    background: rgba(34, 211, 238, 0.15);
    color: #7dd3fc;
    border: 1px solid rgba(34, 211, 238, 0.3);
}

.btn-edit:hover {
    background: rgba(34, 211, 238, 0.3);
    transform: scale(1.05);
    color: white;
}

.btn-delete {
    background: rgba(239, 68, 68, 0.15);
    color: #fca5a5;
    border: 1px solid rgba(239, 68, 68, 0.3);
}

.btn-delete:hover {
    background: rgba(239, 68, 68, 0.3);
    transform: scale(1.05);
    color: white;
}

/* CUSTOM DELETE MODAL - Like your image */
.delete-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 5000;
}

.delete-modal-overlay.active {
    display: flex;
}

.delete-modal {
    background: rgba(20, 25, 35, 0.95);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 75, 75, 0.3);
    border-radius: 24px;
    padding: 30px;
    width: 90%;
    max-width: 350px;
    text-align: center;
    animation: modalPop 0.3s ease;
    box-shadow: 0 20px 40px rgba(255, 0, 0, 0.2);
}

@keyframes modalPop {
    from {
        transform: scale(0.8);
        opacity: 0;
    }
    to {
        transform: scale(1);
        opacity: 1;
    }
}

.delete-modal i {
    font-size: 3.5rem;
    color: #ff6b6b;
    margin-bottom: 15px;
    animation: shake 0.5s ease;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
    20%, 40%, 60%, 80% { transform: translateX(5px); }
}

.delete-modal h5 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 10px;
    color: #fff;
}

.delete-modal p {
    color: rgba(255, 255, 255, 0.7);
    margin-bottom: 20px;
    font-size: 0.95rem;
}

.delete-code {
    background: rgba(255, 75, 75, 0.1);
    border: 1px solid rgba(255, 75, 75, 0.3);
    border-radius: 12px;
    padding: 10px;
    margin-bottom: 20px;
    font-family: monospace;
    font-size: 1.1rem;
    color: #ff6b6b;
    font-weight: 600;
}

.delete-modal-buttons {
    display: flex;
    gap: 10px;
}

.delete-modal-buttons button {
    flex: 1;
    padding: 12px;
    border-radius: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
    cursor: pointer;
}

.btn-cancel {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
}

.btn-cancel:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
}

.btn-delete-confirm {
    background: linear-gradient(135deg, #ff6b6b, #ff4757);
    border: none;
    color: white;
}

.btn-delete-confirm:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(255, 71, 87, 0.4);
}

/* MODAL STYLES */
.modal-content {
    background: rgba(15, 23, 42, 0.95) !important;
    border: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.modal-header {
    border-bottom: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.modal-footer {
    border-top: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.form-control, .form-select {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 12px;
    padding: 10px;
}

.form-control:focus, .form-select:focus {
    background: rgba(0, 0, 0, 0.5);
    border-color: #ffd700;
    box-shadow: 0 0 15px rgba(255, 215, 0, 0.3);
    color: #fff;
    outline: none;
}

/* BACK BUTTON */
.btn-back {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: white;
    padding: 10px 25px;
    border-radius: 50px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    margin-top: 20px;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

.btn-back:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    color: white;
}

/* SCROLLBAR */
::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}
::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #ffd700, #22d3ee);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #22d3ee, #ffd700);
}

@media (max-width: 768px) {
    .rgb-title {
        font-size: 1.5rem;
    }
    .action-buttons {
        flex-direction: column;
    }
}
</style>
</head>

<body>

<div id="particles-js"></div>
<div id="overlay" onclick="toggleSidebar()"></div>

<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <strong style="font-size:1.2rem;">Referral Management</strong>
    </div>
    
    <!-- USER BADGE -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
    </div>
</header>

<!-- SIDEBAR -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                <!-- Image Logo -->
                <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                     style="width:100px; height:100px; border-radius:50%;">
            </div>
        </div>
    </div>

        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($_SESSION['username']) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-edit"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<div class="main">
    
    <!-- ALERT MESSAGES -->
    <?php if(isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i> <?= $_SESSION['success_msg'] ?>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success_msg']); endif; ?>

    <?php if(isset($_SESSION['error_msg'])): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i> <?= $_SESSION['error_msg'] ?>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['error_msg']); endif; ?>

    <!-- RGB TITLE -->
    <div class="rgb-title">
        <i class="fas fa-gift me-3"></i>REFERRAL CODES
    </div>

    <!-- GENERATE CARD -->
    <div class="generate-card">
        <form method="POST" class="row g-3 align-items-end">
            <div class="col-md-8">
                <label class="form-label text-white-50">Assign To</label>
                <select name="assigned_to" class="premium-select" required>
                    <option value="user">👤 User</option>
                    <?php if($is_admin): ?>
                    <option value="admin">🛡️ Admin</option>
                    <?php endif; ?>
                    <?php if($is_owner): ?>
                    <option value="owner">👑 Owner</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" name="generate" class="btn-generate w-100">
                    <i class="fas fa-plus-circle me-2"></i>Generate
                </button>
            </div>
        </form>
    </div>

    <!-- TABLE CONTAINER -->
    <div class="table-container">
        <table class="premium-table">
            <thead>
                <tr>
                    <th><i class="fas fa-hashtag"></i> ID</th>
                    <th><i class="fas fa-code"></i> Code</th>
                    <th><i class="fas fa-tag"></i> Assigned To</th>
                    <th><i class="fas fa-user"></i> Used By</th>
                    <th><i class="fas fa-circle"></i> Status</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($ref = mysqli_fetch_assoc($referrals)): 
                    $status = $ref['used_by'] ? 'used' : 'available';
                    $statusClass = $status == 'available' ? 'status-available' : 'status-used';
                    $statusText = $status == 'available' ? 'AVAILABLE' : 'USED';
                    
                    $assigned_to = $ref['assigned_to'] ?? 'user';
                    $assignedClass = 'role-' . $assigned_to;
                    $assignedIcon = $assigned_to == 'owner' ? 'fa-crown' : ($assigned_to == 'admin' ? 'fa-shield-alt' : 'fa-user');
                ?>
                <tr>
                    <td><span style="color:#ffd700;">#<?= $ref['id'] ?></span></td>
                    <td><code style="background:rgba(255,215,0,0.1); padding:4px 8px; border-radius:8px; color:#ffd700;"><?= $ref['code'] ?></code></td>
                    <td>
                        <span class="role-badge <?= $assignedClass ?>">
                            <i class="fas <?= $assignedIcon ?>"></i>
                            <?= strtoupper($assigned_to) ?>
                        </span>
                    </td>
                    <td>
                        <?php if($ref['used_by']): ?>
                            <span style="color:#4ade80;">
                                <i class="fas fa-user-check me-1"></i><?= htmlspecialchars($ref['used_by_username'] ?? 'User') ?>
                            </span>
                        <?php else: ?>
                            <span style="color:#9ca3af;">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-badge <?= $statusClass ?>">
                            <i class="fas fa-<?= $status == 'available' ? 'check-circle' : 'ban' ?> me-1"></i>
                            <?= $statusText ?>
                        </span>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <!-- Copy Button -->
                            <button class="btn-glass btn-copy" onclick="copyCode('<?= $ref['code'] ?>', this)">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                            
                            <!-- Edit Button (Admin/Owner only) -->
                            <?php if($is_admin): ?>
                            <button class="btn-glass btn-edit" onclick="openEditModal(<?= $ref['id'] ?>, '<?= $assigned_to ?>', <?= $ref['used_by'] ? 0 : 1 ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <?php endif; ?>
                            
                            <!-- Delete Button (Owner only) - Now with custom modal -->
                            <?php if($is_owner): ?>
                            <button class="btn-glass btn-delete" onclick="openDeleteModal(<?= $ref['id'] ?>, '<?= $ref['code'] ?>')">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Back Button -->
        <div class="text-center mt-4">
            <a href="dashboard.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
</div>

<!-- CUSTOM DELETE MODAL - Like your image -->
<div id="deleteModal" class="delete-modal-overlay">
    <div class="delete-modal">
        <i class="fas fa-exclamation-triangle"></i>
        <h5>Delete this referral code?</h5>
        <p>This action cannot be undone.</p>
        <div class="delete-code" id="deleteCodeDisplay">CODE</div>
        
        <form method="post" id="deleteForm">
            <input type="hidden" name="delete_id" id="deleteId">
            <div class="delete-modal-buttons">
                <button type="button" class="btn-cancel" onclick="closeDeleteModal()">Cancel</button>
                <button type="submit" class="btn-delete-confirm">Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- EDIT MODAL (Admin/Owner only) -->
<?php if($is_admin): ?>
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content glass">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2" style="color:#ffd700;"></i>
                    Edit Referral Code
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="code_id" id="edit_code_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Assigned To</label>
                        <select name="assigned_to" class="form-select" id="edit_assigned_to">
                            <option value="user">👤 User</option>
                            <?php if($is_admin): ?>
                            <option value="admin">🛡️ Admin</option>
                            <?php endif; ?>
                            <?php if($is_owner): ?>
                            <option value="owner">👑 Owner</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" id="edit_status">
                            <option value="1">✅ Available</option>
                            <option value="0">❌ Used</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit_code" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Sidebar functions
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('active');
}

// Close sidebar when clicking outside
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.querySelector('.menu-btn');
    const overlay = document.getElementById('overlay');
    
    if (!sidebar.contains(e.target) && !menuBtn.contains(e.target) && sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
});

// Particles
particlesJS("particles-js", {
    particles: {
        number: { value: 60 },
        color: { value: "#ffffff" },
        opacity: { value: 0.4 },
        size: { value: 2 },
        move: { 
            enable: true,
            speed: 0.8,
            direction: "bottom",
            random: true
        }
    }
});

// Copy function with feedback
function copyCode(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
        btn.style.background = 'rgba(34,197,94,0.3)';
        
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.style.background = 'rgba(34,197,94,0.15)';
        }, 2000);
    });
}

// Edit modal function
function openEditModal(id, assignedTo, status) {
    document.getElementById('edit_code_id').value = id;
    document.getElementById('edit_assigned_to').value = assignedTo;
    document.getElementById('edit_status').value = status;
    
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

// Custom Delete Modal functions
function openDeleteModal(id, code) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteCodeDisplay').textContent = code;
    document.getElementById('deleteModal').classList.add('active');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
}

// Auto close overlay
document.getElementById('overlay').onclick = function() {
    document.getElementById('sidebar').classList.remove('active');
    document.getElementById('overlay').classList.remove('active');
};

// Close delete modal when clicking outside
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeDeleteModal();
    }
});
</script>

</body>
</html>