<?php
$servername = "localhost";
$username = "osuuckga_riyaz";
$password = "osuuckga_riyaz";
$dbname = "osuuckga_riyaz";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if (!$conn) {
    die(json_encode(['status' => 'fail', 'reason' => 'Database connection failed']));
}
?>
