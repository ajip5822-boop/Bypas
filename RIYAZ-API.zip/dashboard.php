<?php
session_start();
include("conn.php");

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$current_user = $_SESSION['username']; // Logged in user

/* COUNTS */
$total   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM licenses"))['c'] ?? 0;

// FIXED: Count DISTINCT license_id from activated_packages
$used    = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(DISTINCT license_id) c FROM activated_packages"))['c'] ?? 0;

// FIXED: Unused licenses calculation
$unused  = $total - $used;

$users   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users"))['c'] ?? 0;

// Blocked licenses count from licenses table where status = 0
$blocked = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM licenses WHERE status = 0"))['c'] ?? 0;

// Active licenses count
$active = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM licenses WHERE status = 1"))['c'] ?? 0;

// FIXED: Get licenses with unique device counts
$licenses = mysqli_query($conn,"
SELECT 
    l.license_key, 
    l.expiry_date, 
    l.status,
    l.package_name,
    COUNT(DISTINCT ap.id) as devices_used,
    COUNT(DISTINCT ap.device_id) as unique_devices,
    MAX(ap.last_used) as last_activity,
    (
        SELECT ap2.ip_address 
        FROM activated_packages ap2 
        WHERE ap2.license_id = l.id 
        ORDER BY ap2.last_used DESC 
        LIMIT 1
    ) as last_ip
FROM licenses l
LEFT JOIN activated_packages ap ON ap.license_id = l.id
GROUP BY l.id 
ORDER BY l.id DESC");
?>
<!DOCTYPE html>
<html>
<head>
<title>RSDK Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
    margin:0;
    font-family:'Montserrat',sans-serif;
    background:linear-gradient(120deg,#020617,#0f172a,#1e3a8a,#312e81);
    background-size:400% 400%;
    animation:bg 18s ease infinite;
    color:#fff;
    overflow-x:hidden;
}
@keyframes bg{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

#particles-js{
    position:fixed;
    inset:0;
    z-index:-2;
}

/* GLASS */
.glass, .glass-card, .kpi, .sidebar-btn, header {
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 22px;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
}

/* HEADER */
header{
    position:fixed;
    top:0;
    left:0;
    right:0;
    height:60px;
    padding:0 20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    z-index:1000;
    background: rgba(15, 23, 42, 0.8);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 0;
}
.menu-btn{
    font-size:1.5rem;
    cursor:pointer;
    color:#ffd700;
    transition:all 0.3s ease;
}
.menu-btn:hover{
    transform:scale(1.1) rotate(90deg);
    color:#22d3ee;
}
.user-badge{
    background:rgba(255,215,0,0.15);
    padding:8px 20px;
    border-radius:50px;
    display:flex;
    align-items:center;
    gap:10px;
    border:1px solid rgba(255,215,0,0.3);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    transition:all 0.3s ease;
}
.user-badge:hover{
    background:rgba(255,215,0,0.25);
    transform:scale(1.05);
}
.user-badge i{
    color:#ffd700;
    font-size:1.1rem;
}
.user-badge span{
    font-weight:600;
    color:#fff;
}

/* SIDEBAR */
#sidebar{
    position:fixed;
    top:0;
    left:-280px;
    height:100%;
    width:260px;
    padding-top:80px;
    transition:0.35s cubic-bezier(0.4,0,0.2,1);
    z-index:1100;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
}
#sidebar.active{
    left:0;
}

/* SIDEBAR LOGO */
.sidebar-logo{
    text-align:center;
    margin-bottom:30px;
    padding:0 15px;
}
.logo-container{
    width:100px;
    height:100px;
    margin:0 auto 15px;
    position:relative;
    animation:float 3s ease-in-out infinite;
}
@keyframes float{
    0%{transform:translateY(0px);}
    50%{transform:translateY(-10px);}
    100%{transform:translateY(0px);}
}
.logo-glow{
    width:100%;
    height:100%;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    border-radius:50%;
    padding:3px;
    animation:rotate 4s linear infinite;
}
@keyframes rotate{
    from{transform:rotate(0deg);}
    to{transform:rotate(360deg);}
}
.logo-inner{
    width:100%;
    height:100%;
    background:#1a1f2e;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:2.5rem;
    color:#ffd700;
    animation:pulse 2s ease-in-out infinite;
}
@keyframes pulse{
    0%{box-shadow:0 0 0 0 rgba(255,215,0,0.7);}
    70%{box-shadow:0 0 0 15px rgba(255,215,0,0);}
    100%{box-shadow:0 0 0 0 rgba(255,215,0,0);}
}
.logo-text{
    font-size:1.3rem;
    font-weight:700;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    animation:rgbText 3s linear infinite;
}
@keyframes rgbText{
    0%{filter:hue-rotate(0deg);}
    50%{filter:hue-rotate(180deg);}
    100%{filter:hue-rotate(360deg);}
}
.admin-badge{
    background:linear-gradient(135deg,#ffd700,#ffa500);
    color:#000;
    padding:5px 15px;
    border-radius:50px;
    font-size:0.8rem;
    font-weight:600;
    display:inline-block;
    margin-top:5px;
    animation:glow 2s ease-in-out infinite;
}
@keyframes glow{
    0%{box-shadow:0 0 5px #ffd700;}
    50%{box-shadow:0 0 20px #ffd700;}
    100%{box-shadow:0 0 5px #ffd700;}
}

.sidebar-btn{
    width:90%;
    margin:8px auto;
    padding:12px 16px;
    border-radius:16px;
    border:none;
    background:rgba(255,255,255,.08);
    color:#fff;
    display:flex;
    align-items:center;
    gap:12px;
    transition:all 0.3s cubic-bezier(0.4,0,0.2,1);
    position:relative;
    overflow:hidden;
}
.sidebar-btn::before{
    content:'';
    position:absolute;
    top:0;
    left:-100%;
    width:100%;
    height:100%;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent);
    transition:left 0.5s ease;
}
.sidebar-btn:hover::before{
    left:100%;
}
.sidebar-btn i{
    width:22px;
    text-align:center;
    color:#ffd700;
    transition:all 0.3s ease;
}
.sidebar-btn:hover{
    background:linear-gradient(135deg,#2563eb,#22d3ee);
    transform:translateX(8px);
    box-shadow:0 5px 15px rgba(37,99,235,0.3);
}
.sidebar-btn:hover i{
    color:#fff;
    transform:scale(1.1);
}

/* OVERLAY BLUR */
#overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    opacity:0;
    pointer-events:none;
    transition:.3s;
    z-index:1050;
}
#overlay.active{
    opacity:1;
    pointer-events:auto;
}

/* MAIN */
.main{
    padding:90px 24px 24px;
    max-width:1400px;
    margin:0 auto;
    animation:fadeIn 0.5s ease;
}
@keyframes fadeIn{
    from{opacity:0;transform:translateY(20px);}
    to{opacity:1;transform:translateY(0);}
}

/* RGB TITLE */
.rgb-title{
    font-size:2rem;
    font-weight:700;
    text-align:center;
    margin:30px 0;
    animation:rgbTitle 3s linear infinite;
}
@keyframes rgbTitle{
    0%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
    17%{color:#ff9933;text-shadow:0 0 10px #ff8800;}
    33%{color:#ffff33;text-shadow:0 0 10px #ffff00;}
    50%{color:#33ff33;text-shadow:0 0 10px #00ff00;}
    67%{color:#33ccff;text-shadow:0 0 10px #0099ff;}
    83%{color:#9933ff;text-shadow:0 0 10px #8800ff;}
    100%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
}

/* KPI CARDS */
.kpi-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
    gap:20px;
    margin-bottom:40px;
}
.kpi{
    padding:25px 20px;
    border-radius:22px;
    text-align:center;
    transition:all 0.3s ease;
    animation:cardFloat 3s ease-in-out infinite;
}
@keyframes cardFloat{
    0%{transform:translateY(0px);}
    50%{transform:translateY(-5px);}
    100%{transform:translateY(0px);}
}
.kpi:hover{
    transform:translateY(-10px);
    border-color:#ffd700;
    box-shadow:0 15px 35px rgba(255,215,0,0.2);
}
.kpi-label{
    font-size:0.9rem;
    text-transform:uppercase;
    letter-spacing:1px;
    opacity:0.7;
    margin-bottom:10px;
}
.kpi-value{
    font-size:2.5rem;
    font-weight:700;
    line-height:1;
}
.kpi-value.text-success{ color:#4ade80; text-shadow:0 0 15px #4ade80; }
.kpi-value.text-warning{ color:#fbbf24; text-shadow:0 0 15px #fbbf24; }
.kpi-value.text-danger{ color:#f87171; text-shadow:0 0 15px #f87171; }
.kpi-value.text-info{ color:#22d3ee; text-shadow:0 0 15px #22d3ee; }

/* SECTION TITLE */
.section-title{
    font-size:1.5rem;
    margin:30px 0 20px;
    display:flex;
    align-items:center;
    gap:10px;
}
.section-title i{
    color:#ffd700;
    animation:rotate 3s linear infinite;
}

/* LICENSE CARDS */
.license-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
    gap:20px;
}
.license-card{
    padding:20px;
    border-radius:22px;
    transition:all 0.3s ease;
    animation:cardFloat 3s ease-in-out infinite;
    animation-delay:calc(var(--i) * 0.1s);
    position:relative;
    overflow:hidden;
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
}
.license-card:hover{
    transform:translateY(-5px);
    border-color:#ffd700;
    box-shadow:0 10px 25px rgba(255,215,0,0.2);
}
.license-card.status-blocked{
    border-color:#ef4444;
    background:rgba(239,68,68,0.1);
}
.license-card.status-blocked:hover{
    border-color:#ef4444;
    box-shadow:0 10px 25px rgba(239,68,68,0.2);
}
.status-badge-small{
    position:absolute;
    top:15px;
    right:15px;
    padding:6px 12px;
    border-radius:50px;
    font-size:0.75rem;
    font-weight:600;
    backdrop-filter:blur(5px);
}
.status-badge-small.active{
    background:rgba(34,197,94,0.2);
    color:#4ade80;
    border:1px solid rgba(34,197,94,0.3);
}
.status-badge-small.blocked{
    background:rgba(239,68,68,0.2);
    color:#f87171;
    border:1px solid rgba(239,68,68,0.3);
}
.license-key{
    font-family:monospace;
    font-size:1.1rem;
    font-weight:600;
    color:#ffd700;
    margin-bottom:15px;
    padding-right:70px;
    word-break:break-all;
}
.license-detail{
    display:flex;
    align-items:center;
    gap:8px;
    margin:10px 0;
    color:rgba(255,255,255,0.9);
    font-size:0.95rem;
}
.license-detail i{
    width:20px;
    color:#ffd700;
}
.license-divider{
    height:1px;
    background:rgba(255,215,0,0.2);
    margin:15px 0;
}
.device-badge{
    background:rgba(34,197,94,0.15);
    color:#4ade80;
    padding:4px 12px;
    border-radius:50px;
    font-size:0.8rem;
    display:inline-flex;
    align-items:center;
    gap:5px;
    border:1px solid rgba(34,197,94,0.3);
}
.device-count{
    background:rgba(255,215,0,0.1);
    color:#ffd700;
    padding:4px 10px;
    border-radius:50px;
    font-size:0.8rem;
    font-weight:600;
}
.last-activity{
    font-size:0.8rem;
    color:rgba(255,255,255,0.5);
    margin-top:5px;
}

/* SCROLLBAR */
::-webkit-scrollbar {
    width: 8px;
}
::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg,#ffd700,#22d3ee);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg,#22d3ee,#ffd700);
}

@media(min-width:769px){
    .main{padding-left:24px}
}

@media (max-width:768px){
    .kpi-grid{
        grid-template-columns:repeat(2,1fr);
    }
}
</style>
</head>

<body>

<div id="particles-js"></div>
<div id="overlay" onclick="toggleSidebar()"></div>

<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <strong style="font-size:1.2rem;">RSDK Dashboard</strong>
    </div>
    
    <!-- User Badge -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($current_user) ?></span>
    </div>
</header>

<!-- SIDEBAR -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                    <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                         style="width:100px; height:100px; border-radius:50%;">
                </div>
            </div>
        </div>
        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($current_user) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-cog"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<!-- MAIN -->
<div class="main">
    
    <!-- VIP DASHBOARD TITLE -->
    <div class="rgb-title">VIP DASHBOARD</div>

    <!-- KPI CARDS -->
    <div class="kpi-grid">
        <div class="kpi">
            <div class="kpi-label">Total Licenses</div>
            <div class="kpi-value"><?= $total ?></div>
        </div>
        <div class="kpi">
            <div class="kpi-label">Active</div>
            <div class="kpi-value text-success"><?= $active ?></div>
        </div>
        <div class="kpi">
            <div class="kpi-label">Blocked</div>
            <div class="kpi-value text-danger"><?= $blocked ?></div>
        </div>
        <div class="kpi">
            <div class="kpi-label">Used</div>
            <div class="kpi-value text-info"><?= $used ?></div>
        </div>
        <div class="kpi">
            <div class="kpi-label">Unused</div>
            <div class="kpi-value text-warning"><?= $unused ?></div>
        </div>
        <div class="kpi">
            <div class="kpi-label">Total Users</div>
            <div class="kpi-value"><?= $users ?></div>
        </div>
    </div>

    <!-- LICENSE SECTION -->
    <div class="section-title">
        <i class="fas fa-key"></i>
        Recent Licenses
    </div>

    <!-- LICENSE CARDS - FIXED DEVICE COUNT -->
    <div class="license-grid">
        <?php $i=0; while($r=mysqli_fetch_assoc($licenses)): $i++; 
            $is_blocked = ($r['status'] == 0);
            $device_count = (int)($r['devices_used'] ?? 0);
            $unique_count = (int)($r['unique_devices'] ?? 0);
            
            // Show unique devices if available, otherwise show total
            $display_count = $unique_count > 0 ? $unique_count : $device_count;
        ?>
        <div class="license-card <?= $is_blocked ? 'status-blocked' : '' ?>" style="--i:<?=$i?>">
            
            <!-- Status Badge -->
            <?php if($is_blocked): ?>
            <span class="status-badge-small blocked">
                <i class="fas fa-ban me-1"></i> BLOCKED
            </span>
            <?php else: ?>
            <span class="status-badge-small active">
                <i class="fas fa-check-circle me-1"></i> ACTIVE
            </span>
            <?php endif; ?>
            
            <!-- License Key -->
            <div class="license-key">
                <i class="fas fa-key me-2"></i>
                <?= htmlspecialchars($r['license_key']) ?>
            </div>
            
            <!-- Package Name (if available) -->
            <?php if(!empty($r['package_name'])): ?>
            <div class="license-detail">
                <i class="fas fa-box"></i>
                Package: <?= htmlspecialchars($r['package_name']) ?>
            </div>
            <?php endif; ?>
            
            <!-- Expiry Date -->
            <div class="license-detail">
                <i class="far fa-calendar-alt"></i>
                Expires: <?= $r['expiry_date'] ?>
            </div>
            
            <div class="license-divider"></div>
            
            <!-- Device Information -->
            <div class="d-flex justify-content-between align-items-center">
                <div class="license-detail">
                    <i class="fas fa-plug"></i>
                    Devices: 
                    <span class="device-count ms-1">
                        <?= $display_count ?>
                    </span>
                </div>
                
                <?php if($display_count > 0 && !$is_blocked): ?>
                <span class="device-badge">
                    <i class="fas fa-circle"></i> Active
                </span>
                <?php endif; ?>
            </div>
            
            <!-- Last IP Address -->
            <div class="license-detail">
                <i class="fas fa-network-wired"></i>
                Last IP: <?= !empty($r['last_ip']) ? $r['last_ip'] : '-' ?>
            </div>
            
            <!-- Last Activity (if available) -->
            <?php if(!empty($r['last_activity'])): ?>
            <div class="last-activity">
                <i class="fas fa-clock me-1"></i>
                Last active: <?= date('d M Y H:i', strtotime($r['last_activity'])) ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
    </div>

</div>

<script>
function toggleSidebar(){
    document.getElementById("sidebar").classList.toggle("active");
    document.getElementById("overlay").classList.toggle("active");
}

particlesJS("particles-js",{
    particles:{
        number:{value:80},
        color:{value:"#ffffff"},
        opacity:{value:0.6},
        size:{value:3},
        move:{speed:1,direction:"bottom"}
    }
});
</script>

</body>
</html>