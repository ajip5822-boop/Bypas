<?php
include 'conn.php';
session_start();

// ============================================
// CHECK LOGIN
// ============================================
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$current_user = $_SESSION['username'];

/* ================= DELETE ================= */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_id'])) {
    $id = (int)$_POST['delete_id'];
    $stmt = $conn->prepare("DELETE FROM licenses WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
    header("Location: license_list.php");
    exit;
}

/* ================= EDIT ================= */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['edit_id'])) {
    $stmt = $conn->prepare(
        "UPDATE licenses 
         SET license_key=?, package_name=?, expiry_date=?, status=? 
         WHERE id=?"
    );
    $stmt->bind_param(
        "sssii",
        $_POST['license_key'],
        $_POST['package_name'],
        $_POST['expiry_date'],
        $_POST['status'],
        $_POST['edit_id']
    );
    $stmt->execute();
    header("Location: license_list.php");
    exit;
}

/* ================= FETCH LICENSES ================= */
$result = $conn->query("SELECT * FROM licenses ORDER BY id DESC");

// Function to get connected devices count for a package
function getConnectedDevices($conn, $package_name) {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'devices'");
    if($tableCheck->num_rows == 0) {
        return 0;
    }
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM devices WHERE package_name = ? AND status = 'connected'");
    $stmt->bind_param("s", $package_name);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'] ?? 0;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>🔑 License Keys • VBOX</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
    margin:0;
    font-family: 'Montserrat', sans-serif;
    background:linear-gradient(120deg,#020617,#0f172a,#1e3a8a,#312e81);
    background-size:400% 400%;
    animation:bg 18s ease infinite;
    color:#fff;
    overflow-x:hidden;
    min-height: 100vh;
}
@keyframes bg{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

#particles-js{
    position:fixed;
    inset:0;
    z-index:-2;
}

/* GLASS EFFECT */
.glass, .glass-card, .card, .app-name-section, .glass-btn, .glass-status, .usage-modal, .ios-modal {
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 22px;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
}

/* HEADER */
header{
    position:fixed;
    top:0;
    left:0;
    right:0;
    height:60px;
    padding:0 20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    z-index:1000;
    background: rgba(15, 23, 42, 0.8);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border-bottom: 1px solid rgba(255, 255, 255, 0.18);
}
.menu-btn{
    font-size:1.5rem;
    cursor:pointer;
    color:#ffd700;
    transition:all 0.3s ease;
}
.menu-btn:hover{
    transform:scale(1.1) rotate(90deg);
    color:#22d3ee;
}
.user-badge{
    background:rgba(255,215,0,0.15);
    padding:8px 20px;
    border-radius:50px;
    display:flex;
    align-items:center;
    gap:10px;
    border:1px solid rgba(255,215,0,0.3);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    transition:all 0.3s ease;
}
.user-badge:hover{
    background:rgba(255,215,0,0.25);
    transform:scale(1.05);
}
.user-badge i{
    color:#ffd700;
    font-size:1.1rem;
}
.user-badge span{
    font-weight:600;
    color:#fff;
}

/* SIDEBAR */
#sidebar{
    position:fixed;
    top:0;
    left:-280px;
    height:100%;
    width:260px;
    padding-top:80px;
    transition:0.35s cubic-bezier(0.4,0,0.2,1);
    z-index:1100;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
}
#sidebar.active{
    left:0;
}

/* SIDEBAR LOGO */
.sidebar-logo{
    text-align:center;
    margin-bottom:30px;
    padding:0 15px;
}
.logo-container{
    width:100px;
    height:100px;
    margin:0 auto 15px;
    position:relative;
    animation:float 3s ease-in-out infinite;
}
@keyframes float{
    0%{transform:translateY(0px);}
    50%{transform:translateY(-10px);}
    100%{transform:translateY(0px);}
}
.logo-glow{
    width:100%;
    height:100%;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    border-radius:50%;
    padding:3px;
    animation:rotate 4s linear infinite;
}
@keyframes rotate{
    from{transform:rotate(0deg);}
    to{transform:rotate(360deg);}
}
.logo-inner{
    width:100%;
    height:100%;
    background:#1a1f2e;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:2.5rem;
    color:#ffd700;
    animation:pulse 2s ease-in-out infinite;
}
@keyframes pulse{
    0%{box-shadow:0 0 0 0 rgba(255,215,0,0.7);}
    70%{box-shadow:0 0 0 15px rgba(255,215,0,0);}
    100%{box-shadow:0 0 0 0 rgba(255,215,0,0);}
}
.logo-text{
    font-size:1.3rem;
    font-weight:700;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    animation:rgbText 3s linear infinite;
}
@keyframes rgbText{
    0%{filter:hue-rotate(0deg);}
    50%{filter:hue-rotate(180deg);}
    100%{filter:hue-rotate(360deg);}
}
.admin-badge{
    background:linear-gradient(135deg,#ffd700,#ffa500);
    color:#000;
    padding:5px 15px;
    border-radius:50px;
    font-size:0.8rem;
    font-weight:600;
    display:inline-block;
    margin-top:5px;
    animation:glow 2s ease-in-out infinite;
}
@keyframes glow{
    0%{box-shadow:0 0 5px #ffd700;}
    50%{box-shadow:0 0 20px #ffd700;}
    100%{box-shadow:0 0 5px #ffd700;}
}

.sidebar-btn{
    width:90%;
    margin:8px auto;
    padding:12px 16px;
    border-radius:16px;
    border:none;
    background:rgba(255,255,255,.08);
    color:#fff;
    display:flex;
    align-items:center;
    gap:12px;
    transition:all 0.3s cubic-bezier(0.4,0,0.2,1);
    position:relative;
    overflow:hidden;
}
.sidebar-btn::before{
    content:'';
    position:absolute;
    top:0;
    left:-100%;
    width:100%;
    height:100%;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent);
    transition:left 0.5s ease;
}
.sidebar-btn:hover::before{
    left:100%;
}
.sidebar-btn i{
    width:22px;
    text-align:center;
    color:#ffd700;
    transition:all 0.3s ease;
}
.sidebar-btn:hover{
    background:linear-gradient(135deg,#2563eb,#22d3ee);
    transform:translateX(8px);
    box-shadow:0 5px 15px rgba(37,99,235,0.3);
}
.sidebar-btn:hover i{
    color:#fff;
    transform:scale(1.1);
}

/* OVERLAY */
#overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    opacity:0;
    pointer-events:none;
    transition:.3s;
    z-index:1050;
}
#overlay.active{
    opacity:1;
    pointer-events:auto;
}

/* MAIN */
.main{
    padding:90px 24px 24px;
    max-width: 1400px;
    margin: 0 auto;
    animation:fadeIn 0.5s ease;
}
@keyframes fadeIn{
    from{opacity:0;transform:translateY(20px);}
    to{opacity:1;transform:translateY(0);}
}

/* PAGE TITLE */
.page-title{
    font-size:2rem;
    font-weight:700;
    text-align:center;
    margin:20px 0 30px;
    animation:rgbTitle 3s linear infinite;
}
@keyframes rgbTitle{
    0%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
    17%{color:#ff9933;text-shadow:0 0 10px #ff8800;}
    33%{color:#ffff33;text-shadow:0 0 10px #ffff00;}
    50%{color:#33ff33;text-shadow:0 0 10px #00ff00;}
    67%{color:#33ccff;text-shadow:0 0 10px #0099ff;}
    83%{color:#9933ff;text-shadow:0 0 10px #8800ff;}
    100%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
}

/* GRID for cards */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(350px,1fr));
    gap:20px;
    margin-top:20px;
}

/* CARD STYLES */
.card{
    padding:20px;
    position:relative;
    transition: all 0.3s ease;
    border-radius:22px;
    overflow: hidden;
}
.card:hover{
    transform:translateY(-5px);
    box-shadow:0 15px 45px rgba(0,0,0,.6);
    border-color: rgba(255, 215, 0, 0.3);
}

/* APP NAME SECTION */
.app-name-section{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:15px;
    background:rgba(255,215,0,0.08);
    padding:12px 15px;
    border-radius:16px;
    border:1px solid rgba(255,215,0,0.3);
}

.app-name-left{
    display:flex;
    align-items:center;
    gap:12px;
}

.app-name-icon{
    width:40px;
    height:40px;
    background:rgba(255,215,0,0.15);
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#ffd700;
    font-size:1.3rem;
}

.app-name-text{
    display:flex;
    flex-direction:column;
}

.app-name-label{
    font-size:0.7rem;
    color:#ffd700;
    text-transform:uppercase;
    letter-spacing:1px;
    opacity:0.8;
}

.app-name-value{
    font-size:1.2rem;
    font-weight:700;
    color:white;
    line-height:1.2;
}

.app-name-edit{
    background:rgba(255,215,0,0.1);
    border:1px solid rgba(255,215,0,0.3);
    color:#ffd700;
    border-radius:10px;
    padding:6px 12px;
    font-size:11px;
    cursor:pointer;
    transition:all 0.3s ease;
    display:flex;
    align-items:center;
    gap:5px;
}
.app-name-edit:hover{
    background:rgba(255,215,0,0.3);
    transform: scale(1.05);
}

/* EDIT INPUT for App Name */
.name-edit-input{
    display:none;
    margin-bottom:15px;
    background:rgba(0,0,0,0.3);
    padding:15px;
    border-radius:16px;
    border: 1px solid rgba(255,215,0,0.2);
}
.name-edit-input.active{
    display:block;
    animation: slideDown 0.3s ease;
}
@keyframes slideDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}
.name-edit-field{
    background:rgba(0,0,0,0.5);
    border:1px solid #ffd700;
    color:white;
    border-radius:12px;
    padding:10px 12px;
    width:100%;
    margin-bottom:10px;
}
.name-edit-field:focus{
    outline:none;
    box-shadow:0 0 15px rgba(255,215,0,0.3);
}

/* PACKAGE NAME - RGB */
.package-rgb{
    animation:rgb-animation 4s linear infinite;
    font-size:1rem;
    margin-bottom:12px;
    display:flex;
    align-items:center;
    gap:8px;
    opacity:1 !important;
    padding:5px 0 5px 8px;
    border-left:3px solid rgba(255,215,0,0.5);
}
.package-rgb i{
    color:#ffd700;
    font-size:0.9rem;
}

/* EXPIRY DATE - RGB */
.expiry-rgb{
    animation:rgb-animation 4s linear infinite;
    font-size:1rem;
    margin-bottom:12px;
    display:flex;
    align-items:center;
    gap:8px;
    opacity:1 !important;
    padding:5px 0 5px 8px;
}
.expiry-rgb i{
    color:#ffd700;
    font-size:0.9rem;
}

/* LICENSE KEY - RGB with blur and eye icon */
.license-key-rgb{
    animation:rgb-animation 4s linear infinite;
    background:rgba(0,0,0,.5);
    border:1px dashed rgba(255,215,0,0.4);
    padding:12px;
    border-radius:14px;
    font-family:'Courier New',monospace;
    margin:15px 0;
    display:flex;
    align-items:center;
    gap:10px;
    word-break:break-all;
}
.license-key-text {
    flex:1;
    font-weight:600;
    font-size:0.95rem;
    transition: filter 0.2s ease;
    color: #fff;
}
.license-key-text.blurred {
    filter: blur(5px);
    user-select: none;
}
.toggle-visibility {
    background: none;
    border: none;
    color: #ffd700;
    cursor: pointer;
    padding: 0 5px;
    font-size: 1.1rem;
    transition: color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
}
.toggle-visibility:hover {
    color: #fff;
}

/* ACTION BAR */
.action-bar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    flex-wrap:wrap;
    gap:10px;
    margin-top:15px;
    padding-top:15px;
    border-top:1px solid rgba(255,215,0,0.2);
}

/* GLASSY BUTTONS */
.glass-buttons{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}

.glass-btn{
    padding:8px 16px;
    border-radius:50px;
    font-size:12px;
    font-weight:600;
    letter-spacing:0.5px;
    border:1px solid rgba(255,255,255,0.2);
    display:inline-flex;
    align-items:center;
    gap:6px;
    transition:all 0.3s ease;
    cursor:pointer;
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    box-shadow:0 4px 12px rgba(0,0,0,0.2);
    background: rgba(255,255,255,0.05);
}
.glass-btn:hover{
    transform:scale(1.05);
    box-shadow:0 0 20px currentColor;
}

.btn-copy-glass{
    color:#a5b4fc;
    border-color:rgba(139,92,246,0.3);
}
.btn-copy-glass:hover{
    background:rgba(99,102,241,0.3);
    color:white;
}

.btn-usage-glass{
    color:#7dd3fc;
    border-color:rgba(6,182,212,0.3);
}
.btn-usage-glass:hover{
    background:rgba(6,182,212,0.3);
    color:white;
}

.btn-edit-glass{
    color:#fde047;
    border-color:rgba(234,179,8,0.3);
}
.btn-edit-glass:hover{
    background:rgba(234,179,8,0.3);
    color:white;
}

.btn-delete-glass{
    color:#fca5a5;
    border-color:rgba(239,68,68,0.3);
}
.btn-delete-glass:hover{
    background:rgba(239,68,68,0.3);
    color:white;
}

/* GLASSY STATUS BADGE */
.glass-status{
    padding:8px 18px;
    border-radius:50px;
    font-size:12px;
    font-weight:700;
    letter-spacing:0.5px;
    display:inline-flex;
    align-items:center;
    gap:8px;
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    box-shadow:0 4px 12px rgba(0,0,0,0.2);
    background: rgba(255,255,255,0.05);
}
.status-active-glass{
    color:#86efac;
    border-color:rgba(34,197,94,0.3);
}
.status-block-glass{
    color:#fecaca;
    border-color:rgba(239,68,68,0.3);
}
.status-pause-glass{
    color:#fde047;
    border-color:rgba(234,179,8,0.3);
}

/* USAGE MODAL */
.usage-modal-overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.85);
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:4000;
}
.usage-modal-overlay.active{
    display:flex;
}
.usage-modal{
    width:90%;
    max-width:500px;
    padding:25px;
    text-align:center;
    border-radius:24px;
    animation:pop 0.3s ease;
    background: rgba(20, 25, 35, 0.95);
    border: 1px solid rgba(255, 215, 0, 0.2);
}
@keyframes pop{
    from{transform:scale(0.9);opacity:0}
    to{transform:scale(1);opacity:1}
}

.usage-stats{
    display:flex;
    flex-direction:column;
    gap:12px;
    margin:20px 0;
    background:rgba(255,255,255,0.03);
    border-radius:16px;
    padding:15px;
}

.usage-stat-item{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:12px 15px;
    background:rgba(255,255,255,0.05);
    border-radius:12px;
    border:1px solid rgba(255,215,0,0.15);
}

.usage-stat-label{
    font-size:0.9rem;
    color:#aaa;
    display:flex;
    align-items:center;
    gap:6px;
}
.usage-stat-label i{
    color:#ffd700;
    width:20px;
}

.usage-stat-value{
    font-size:1.3rem;
    font-weight:700;
    color:#ffd700;
}

.usage-device-list{
    max-height:300px;
    overflow-y:auto;
    margin-top:20px;
    text-align:left;
    padding:5px;
    border-top:1px solid rgba(255,215,0,0.2);
    padding-top:15px;
}

.usage-device-item{
    padding:15px;
    border-bottom:1px solid rgba(255,255,255,0.1);
    font-size:0.95rem;
    display:flex;
    align-items:flex-start;
    gap:12px;
    transition:all 0.3s ease;
    background:rgba(255,255,255,0.02);
    border-radius:10px;
    margin-bottom:8px;
}
.usage-device-item:hover{
    background:rgba(255,255,255,0.05);
    transform:translateX(5px);
}
.usage-device-item i.fa-circle{
    color:#4ade80;
    font-size:0.7rem;
    margin-top:6px;
    animation:pulse 2s infinite;
}
.device-info{
    flex:1;
}
.device-id{
    color:#ffd700;
    font-weight:600;
    font-size:1rem;
    margin-bottom:5px;
}
.device-meta{
    display:flex;
    gap:20px;
    font-size:0.85rem;
    color:#aaa;
}
.device-meta span{
    display:flex;
    align-items:center;
    gap:5px;
}
.device-meta i{
    color:#ffd700;
    width:16px;
}

/* DELETE MODAL */
.ios-modal-overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.8);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:3000;
}
.ios-modal-overlay.active{
    display:flex;
}
.ios-modal{
    width:90%;
    max-width:320px;
    padding:25px;
    text-align:center;
    border-radius:22px;
    animation:pop .25s ease;
    background: rgba(15,23,42,0.95);
}

/* RGB ANIMATION */
@keyframes rgb-animation{
    0%{color:#ff3333;text-shadow:0 0 10px #ff0000,0 0 20px #ff0000;}
    14%{color:#ff9933;text-shadow:0 0 10px #ff8800,0 0 20px #ff8800;}
    28%{color:#ffff33;text-shadow:0 0 10px #ffff00,0 0 20px #ffff00;}
    42%{color:#33ff33;text-shadow:0 0 10px #00ff00,0 0 20px #00ff00;}
    57%{color:#33ccff;text-shadow:0 0 10px #0099ff,0 0 20px #0099ff;}
    71%{color:#6666ff;text-shadow:0 0 10px #0000ff,0 0 20px #0000ff;}
    85%{color:#9933ff;text-shadow:0 0 10px #8800ff,0 0 20px #8800ff;}
    100%{color:#ff3333;text-shadow:0 0 10px #ff0000,0 0 20px #ff0000;}
}

/* FORM STYLES */
.form-control{
    background:rgba(0,0,0,0.3);
    border:1px solid rgba(255,255,255,0.1);
    color:#fff;
    border-radius:12px;
    padding:10px;
}
.form-control:focus{
    background:rgba(0,0,0,0.5);
    border-color:#ffd700;
    box-shadow:0 0 15px rgba(255,215,0,0.3);
    color:#fff;
    outline:none;
}
.form-control option{
    background:#1a2634;
}

/* CUSTOM NAME */
.custom-name{
    font-weight:600;
}

/* SCROLLBAR */
::-webkit-scrollbar {
    width: 8px;
}
::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: rgba(255,215,0,0.3);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: rgba(255,215,0,0.5);
}

@media(min-width:769px){
    .main{padding-left:24px}
}

@media (max-width: 768px) {
    .action-bar {
        flex-direction: column;
        align-items: stretch;
    }
    .glass-buttons {
        justify-content: center;
    }
    .glass-status {
        justify-content: center;
    }
    .device-meta{
        flex-direction:column;
        gap:5px;
    }
}
</style>
</head>

<body>

<div id="particles-js"></div>
<div id="overlay" onclick="toggleSidebar()"></div>

<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <strong style="font-size:1.2rem;">License List</strong>
    </div>
    
    <!-- User Badge -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($current_user) ?></span>
    </div>
</header>

<!-- SIDEBAR WITH LOGO -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                    <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                         style="width:100px; height:100px; border-radius:50%;">
                </div>
            </div>
        </div>
        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($current_user) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-cog"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<div class="main">
    <div class="page-title">
        <i class="fas fa-key me-3"></i>LICENSE KEYS
    </div>

    <div class="grid">
    <?php 
    if($result->num_rows > 0) {
        while($r=$result->fetch_assoc()):
            $statusText = "ACTIVE";
            $statusClass = "status-active-glass";
            if($r['status'] == 0) {
                $statusText = "BLOCKED";
                $statusClass = "status-block-glass";
            } elseif($r['status'] == 2) {
                $statusText = "PAUSED";
                $statusClass = "status-pause-glass";
            }
            
            // Get connected devices count
            $devices_count = getConnectedDevices($conn, $r['package_name']);
    ?>
    <div class="card">
        <!-- App Name Section -->
        <div class="app-name-section">
            <div class="app-name-left">
                <div class="app-name-icon">
                    <i class="fas fa-crown"></i>
                </div>
                <div class="app-name-text">
                    <span class="app-name-label">APP NAME</span>
                    <div class="app-name-value" id="appNameDisplay<?=$r['id']?>">
                        <span class="custom-name"><?=htmlspecialchars($r['package_name'])?></span>
                    </div>
                </div>
            </div>
            <button class="app-name-edit" onclick="showNameInput(<?=$r['id']?>)">
                <i class="fas fa-pencil-alt"></i> Change
            </button>
        </div>

        <!-- Hidden Edit Input for App Name -->
        <div class="name-edit-input" id="nameInput<?=$r['id']?>">
            <input type="text" class="name-edit-field" id="newName<?=$r['id']?>" 
                   placeholder="Enter custom app name..." 
                   value="<?=htmlspecialchars($r['package_name'])?>">
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-success" onclick="saveName(<?=$r['id']?>)">
                    <i class="fas fa-check"></i> Save
                </button>
                <button class="btn btn-sm btn-secondary" onclick="hideNameInput(<?=$r['id']?>)">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        </div>

        <!-- Package Name - RGB -->
        <div class="package-rgb">
            <i class="fas fa-box"></i>
            Package: <?=htmlspecialchars($r['package_name'])?>
        </div>

        <!-- Expiry Date - RGB -->
        <div class="expiry-rgb">
            <i class="far fa-calendar-alt"></i>
            <?=htmlspecialchars($r['expiry_date'])?>
        </div>

        <!-- License Key - RGB with blur and eye icon -->
        <div class="license-key-rgb" id="k<?=$r['id']?>">
            <i class="fas fa-key"></i>
            <span class="license-key-text blurred" id="keyText<?=$r['id']?>"><?=htmlspecialchars($r['license_key'])?></span>
            <button class="toggle-visibility" onclick="toggleKeyVisibility(<?=$r['id']?>)" title="Toggle visibility">
                <i class="fas fa-eye" id="eyeIcon<?=$r['id']?>"></i>
            </button>
        </div>

        <!-- Action Bar -->
        <div class="action-bar">
            <div class="glass-buttons">
                <!-- Copy Button -->
                <button class="glass-btn btn-copy-glass" onclick="copyKey('<?=$r['id']?>', this)">
                    <i class="far fa-copy"></i> Copy
                </button>

                <!-- Usage Button -->
                <button class="glass-btn btn-usage-glass" onclick="showUsage('<?=$r['package_name']?>', this)">
                    <i class="fas fa-chart-line"></i> Usage (<?=$devices_count?>)
                </button>

                <!-- Edit Button -->
                <button class="glass-btn btn-edit-glass" data-bs-toggle="modal" data-bs-target="#edit<?=$r['id']?>">
                    <i class="fas fa-edit"></i> Edit
                </button>

                <!-- Delete Button -->
                <button class="glass-btn btn-delete-glass" onclick="openDeleteModal(<?=$r['id']?>)">
                    <i class="fas fa-trash-alt"></i> Delete
                </button>
            </div>

            <!-- Status Badge -->
            <span class="glass-status <?=$statusClass?>">
                <i class="fas fa-<?=($statusText=='ACTIVE'?'check-circle':($statusText=='BLOCKED'?'ban':'pause-circle'))?>"></i>
                <?=$statusText?>
            </span>
        </div>
    </div>

    <!-- EDIT MODAL -->
    <div class="modal fade" id="edit<?=$r['id']?>" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content glass text-white">
                <form method="post">
                    <div class="modal-header border-0">
                        <h5><i class="fas fa-edit me-2 text-info"></i>Edit License</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="edit_id" value="<?=$r['id']?>">
                        
                        <label class="mb-1"><i class="fas fa-key me-2" style="color:#ffd700;"></i>License Key</label>
                        <input class="form-control mb-3" name="license_key" value="<?=htmlspecialchars($r['license_key'])?>" required>
                        
                        <label class="mb-1"><i class="fas fa-box me-2" style="color:#ffd700;"></i>Package Name</label>
                        <input class="form-control mb-3" name="package_name" value="<?=htmlspecialchars($r['package_name'])?>" required>
                        
                        <label class="mb-1"><i class="far fa-calendar-alt me-2" style="color:#ffd700;"></i>Expiry Date</label>
                        <input type="date" class="form-control mb-3" name="expiry_date" value="<?=$r['expiry_date']?>" required>

                        <label class="mb-1"><i class="fas fa-circle me-2" style="color:#ffd700;"></i>Status</label>
                        <select class="form-control mb-2" name="status" required>
                            <option value="1" <?=$r['status']==1?'selected':''?>>✅ ACTIVE</option>
                            <option value="2" <?=$r['status']==2?'selected':''?>>⏸️ PAUSED</option>
                            <option value="0" <?=$r['status']==0?'selected':''?>>❌ BLOCKED</option>
                        </select>
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">
                            <i class="fas fa-times me-2"></i>Cancel
                        </button>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fas fa-save me-2"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php 
        endwhile; 
    } else {
        echo '<div class="col-12 text-center p-5">
                <i class="fas fa-key fa-4x mb-3 opacity-50"></i>
                <h5>No Licenses Found</h5>
                <p class="opacity-75">Click Generate License to create new licenses</p>
                <a href="generate_ui.php" class="btn btn-primary mt-2">
                    <i class="fas fa-plus-circle me-2"></i>Generate License
                </a>
              </div>';
    }
    ?>
    </div>
</div>

<!-- USAGE MODAL -->
<div id="usageModal" class="usage-modal-overlay">
    <div class="usage-modal">
        <i class="fas fa-chart-line fa-3x mb-3" style="color:#7dd3fc;"></i>
        <h5 class="mb-3">Connected Devices</h5>
        
        <div class="usage-stats">
            <div class="usage-stat-item">
                <span class="usage-stat-label"><i class="fas fa-box"></i> Package Name</span>
                <span class="usage-stat-value" id="usagePackageName">-</span>
            </div>
            <div class="usage-stat-item">
                <span class="usage-stat-label"><i class="fas fa-plug"></i> Connected Devices</span>
                <span class="usage-stat-value" id="usageDeviceCount">0</span>
            </div>
        </div>

        <div class="usage-device-list" id="usageDeviceList">
            <div class="text-center py-4">
                <i class="fas fa-info-circle fa-2x mb-2" style="color:#9ca3af;"></i>
                <p>Select a package to view connected devices</p>
            </div>
        </div>

        <div class="d-flex justify-content-center mt-3">
            <button class="btn btn-outline-light" onclick="closeUsageModal()">
                <i class="fas fa-times me-2"></i>Close
            </button>
        </div>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="ios-modal-overlay">
    <div class="ios-modal">
        <i class="fas fa-exclamation-triangle fa-3x mb-3 text-warning"></i>
        <h5 class="mb-2">Delete License?</h5>
        <p class="opacity-75">This action cannot be undone!</p>

        <div class="d-flex gap-2 mt-4">
            <button class="btn btn-outline-light w-50" onclick="closeDeleteModal()">
                <i class="fas fa-times me-2"></i>Cancel
            </button>
            <button class="btn btn-danger w-50" onclick="confirmDelete()">
                <i class="fas fa-trash-alt me-2"></i>Delete
            </button>
        </div>
    </div>
</div>

<form id="deleteForm" method="post" style="display:none">
    <input type="hidden" name="delete_id" id="deleteId">
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>

<script>
// Particles.js
particlesJS("particles-js", {
    particles: {
        number: { value: 60 },
        color: { value: "#ffffff" },
        opacity: { value: 0.4 },
        size: { value: 2 },
        move: { 
            enable: true,
            speed: 0.8,
            direction: "bottom",
            random: true
        }
    }
});

// Load saved names from localStorage
document.addEventListener('DOMContentLoaded', function() {
    <?php 
    if($result->num_rows > 0) {
        mysqli_data_seek($result, 0);
        while($r=$result->fetch_assoc()): 
    ?>
    const savedName<?=$r['id']?> = localStorage.getItem('app_name_<?=$r['id']?>');
    if(savedName<?=$r['id']?>) {
        document.getElementById('appNameDisplay<?=$r['id']?>').innerHTML = 
            '<span class="custom-name">' + savedName<?=$r['id']?> + '</span>';
    }
    <?php 
        endwhile; 
    } 
    ?>
});

// Sidebar functions
const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");

function toggleSidebar() {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("active");
}

function closeSidebar() {
    sidebar.classList.remove("active");
    overlay.classList.remove("active");
}

// Toggle license key visibility (blur on/off)
function toggleKeyVisibility(id) {
    const keyText = document.getElementById('keyText' + id);
    const eyeIcon = document.getElementById('eyeIcon' + id);
    keyText.classList.toggle('blurred');
    if (keyText.classList.contains('blurred')) {
        eyeIcon.className = 'fas fa-eye';
    } else {
        eyeIcon.className = 'fas fa-eye-slash';
    }
}

// Copy function
function copyKey(id, btn) {
    const element = document.getElementById('keyText' + id);
    const text = element.innerText.trim(); // Get the actual text (no blur in copy)
    
    navigator.clipboard.writeText(text).then(() => {
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
        
        setTimeout(() => {
            btn.innerHTML = originalText;
        }, 2000);
    });
}

// Show name input
function showNameInput(id) {
    document.getElementById('nameInput' + id).classList.add('active');
}

// Hide name input
function hideNameInput(id) {
    document.getElementById('nameInput' + id).classList.remove('active');
}

// Save custom name
function saveName(id) {
    const newName = document.getElementById('newName' + id).value;
    if (newName.trim() !== '') {
        localStorage.setItem('app_name_' + id, newName);
        document.getElementById('appNameDisplay' + id).innerHTML = 
            '<span class="custom-name">' + newName + '</span>';
        hideNameInput(id);
        showToast('App name saved successfully!', 'success');
    } else {
        showToast('Please enter a name', 'error');
    }
}

// Usage function - FETCH REAL DEVICES WITH IP ADDRESSES
function showUsage(packageName, btn) {
    document.getElementById('usagePackageName').textContent = packageName;
    
    const deviceList = document.getElementById('usageDeviceList');
    deviceList.innerHTML = '<div class="text-center py-4"><i class="fas fa-spinner fa-spin fa-2x mb-2"></i><p>Loading devices...</p></div>';
    document.getElementById('usageDeviceCount').textContent = '...';
    
    // Show modal immediately with loading state
    document.getElementById('usageModal').classList.add('active');
    
    // AJAX call to get real devices with IP addresses
    fetch(`get_devices.php?package=${encodeURIComponent(packageName)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Devices data:', data);
            
            if (data.success && data.devices && data.devices.length > 0) {
                let html = '';
                data.devices.forEach(device => {
                    const lastSeen = device.last_seen ? new Date(device.last_seen).toLocaleString() : 'Just now';
                    const ipDisplay = device.ip_address || 'N/A';
                    
                    html += `
                        <div class="usage-device-item">
                            <i class="fas fa-circle"></i>
                            <div class="device-info">
                                <div class="device-id">${device.device_id}</div>
                                <div class="device-meta">
                                    <span><i class="fas fa-network-wired"></i> ${ipDisplay}</span>
                                    <span><i class="fas fa-clock"></i> ${lastSeen}</span>
                                </div>
                            </div>
                        </div>
                    `;
                });
                deviceList.innerHTML = html;
                document.getElementById('usageDeviceCount').textContent = data.devices.length;
            } else {
                deviceList.innerHTML = `
                    <div class="text-center py-5">
                        <i class="fas fa-info-circle fa-3x mb-3" style="color:#9ca3af;"></i>
                        <h6 class="mb-2">No Devices Connected</h6>
                        <p class="small opacity-50">Package: ${packageName}</p>
                        <p class="small opacity-50">Connect a device to see IP address</p>
                    </div>
                `;
                document.getElementById('usageDeviceCount').textContent = '0';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            deviceList.innerHTML = `
                <div class="text-center py-4">
                    <i class="fas fa-exclamation-triangle fa-2x mb-2" style="color:#f87171;"></i>
                    <p class="text-danger">Error loading devices</p>
                    <p class="small opacity-50">${error.message}</p>
                </div>
            `;
            document.getElementById('usageDeviceCount').textContent = '0';
        });
}

// Close usage modal
function closeUsageModal() {
    document.getElementById('usageModal').classList.remove('active');
}

// Toast message
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 12px 24px;
        border-radius: 50px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    `;
    toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} me-2"></i>${message}`;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Delete modal functions
let deleteTargetId = null;

function openDeleteModal(id) {
    deleteTargetId = id;
    document.getElementById("deleteModal").classList.add("active");
}

function closeDeleteModal() {
    document.getElementById("deleteModal").classList.remove("active");
    deleteTargetId = null;
}

function confirmDelete() {
    if (deleteTargetId) {
        document.getElementById("deleteId").value = deleteTargetId;
        document.getElementById("deleteForm").submit();
    }
}

// Close modals on outside click
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeDeleteModal();
    }
});

document.getElementById('usageModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeUsageModal();
    }
});

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);
</script>

</body>
</html>