<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
include('conn.php');

$license_id = intval($_GET['license_id']);

// Toggle package active/deactive
if (isset($_POST['toggle'])) {
    $pkg_id = intval($_POST['id']);
    $status = intval($_POST['status']);
    mysqli_query($conn, "UPDATE activated_packages SET is_allowed=$status WHERE id=$pkg_id");
}

// Fetch packages for this license
$pkgs = mysqli_query($conn, "SELECT * FROM activated_packages WHERE license_id=$license_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Activated Packages</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #121212;
            color: #fff;
            padding: 40px 15px;
            font-family: 'Segoe UI', sans-serif;
        }
        .package-box {
            background: #1f1c2c;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 15px;
        }
        .btn-toggle {
            width: 100px;
        }
        /* Sidebar styling */
        #sidebar {
            position: fixed;
            top: 0;
            right: -260px;
            height: 100%;
            width: 260px;
            background: rgba(40, 40, 60, 0.95);
            backdrop-filter: blur(8px);
            padding-top: 20px;
            transition: right 0.3s ease;
            z-index: 9999;
            border-left: 1px solid #555;
        }
        #sidebar.active { right: 0; }
        .sidebar-header {
            text-align: center;
            margin-bottom: 25px;
        }
        .vip-icon-box {
            width: 50px;
            height: 50px;
            margin: 0 auto;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            border-radius: 12px;
            box-shadow: 0 8px 15px rgba(255, 65, 108, 0.4);
        }
        .sidebar-title {
            margin-top: 10px;
            font-size: 1.2rem;
            font-weight: bold;
            color: #ffdfdf;
        }
        .sidebar-btn {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid #6c757d;
            color: #fff;
            text-align: center;
            width: 80%;
            margin: 10px auto;
            padding: 10px 15px;
            font-size: 0.95rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
            display: block;
        }
        .sidebar-btn:hover {
            background-color: #6c757d;
            transform: scale(1.03);
        }
        .hamburger {
            cursor: pointer;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 20px;
            height: 14px;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .hamburger span {
            display: block;
            height: 2.5px;
            background-color: white;
            border-radius: 2px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div id="sidebar">
    <div class="sidebar-header">
        <div class="vip-icon-box"></div>
        <div class="sidebar-title">VIP Panel</div>
    </div>
    <button class="sidebar-btn" onclick="location.href='dashboard.php'">Dashboard</button>
    <button class="sidebar-btn" onclick="location.href='license_check_ui.php'">Check Licenses</button>
    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">Generate License</button>
    <button class="sidebar-btn" onclick="location.href='edit_license.php'">Edit License</button>
    <button class="sidebar-btn" onclick="location.href='manage_users.php'">Manage Users</button>
    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">Manage Referrals</button>
    <button class="sidebar-btn" onclick="location.href='manage_packaes.php'">Packaes Edit</button>
    <button class="sidebar-btn" onclick="location.href='logout.php'">Logout</button>
</div>

<!-- Hamburger Menu -->
<div class="hamburger" onclick="toggleSidebar()">
    <span></span>
    <span></span>
    <span></span>
</div>

<h2 class="text-center mb-4">Manage Activated Packages</h2>

<?php while($pkg = mysqli_fetch_assoc($pkgs)): ?>
<div class="package-box">
    <div><b>Package Name:</b> <?= htmlspecialchars($pkg['package_name']) ?></div>
    <div><b>Usage Count:</b> <?= $pkg['usage_count'] ?></div>
    <div><b>Last Used:</b> <?= $pkg['last_used'] ?></div>
    <form method="POST" class="mt-2">
        <input type="hidden" name="id" value="<?= $pkg['id'] ?>">
        <input type="hidden" name="status" value="<?= $pkg['is_allowed'] ? 0 : 1 ?>">
        <button type="submit" name="toggle" class="btn btn-sm <?= $pkg['is_allowed'] ? 'btn-danger' : 'btn-success' ?> btn-toggle">
            <?= $pkg['is_allowed'] ? 'Block' : 'Allow' ?>
        </button>
    </form>
</div>
<?php endwhile; ?>

<div class="text-center">
    <a href="edit_license.php" class="btn btn-secondary">Back to Licenses</a>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.querySelector('.hamburger');
    if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('active');
    }
});
</script>

</body>
</html>
