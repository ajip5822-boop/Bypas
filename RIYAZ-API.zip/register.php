<?php
session_start();
include('conn.php');

// Handle registration
if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $referral = mysqli_real_escape_string($conn, $_POST['referral_code']);

    $refCheck = mysqli_query($conn, "SELECT * FROM referral_codes WHERE code='$referral' AND used_by IS NULL");
    if (mysqli_num_rows($refCheck) === 0) {
        echo "<script>alert('Invalid or already used referral code!');</script>";
    } else {
        $hashed = sha1($password); // Consider using password_hash() for better security
        $insertUser = mysqli_query($conn, "INSERT INTO users (username, password) VALUES ('$username', '$hashed')");
        if ($insertUser) {
            $user_id = mysqli_insert_id($conn);
            mysqli_query($conn, "UPDATE referral_codes SET used_by = $user_id WHERE code = '$referral'");
            header("Location: login.php");
            exit();
        } else {
            echo "<script>alert('Username already exists!');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>RGB Register | animated premium title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap & Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Particles.js -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', 'Roboto', sans-serif;
            user-select: auto !important;
            -webkit-user-select: auto !important;
        }

        body {
            background: #000000;
            color: white;
            overflow: hidden;
            height: 100vh;
            position: relative;
        }

        /* particles container */
        #particles-js {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 1;
            background: #000000;
        }

        /* page container sits above particles */
        .page-container {
            position: relative;
            z-index: 10;
            display: flex;
            min-height: 100vh;
            width: 100%;
        }

        /* MAIN CONTENT - center card */
        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        /* GLASS CARD */
        .register-card {
            width: 460px; /* slightly wider for bigger title */
            padding: 45px 40px;
            background: rgba(0, 0, 0, 0.45);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 50px;
            backdrop-filter: blur(20px) saturate(200%);
            -webkit-backdrop-filter: blur(20px) saturate(200%);
            box-shadow: 0 35px 60px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(255,255,255,0.05) inset;
        }

        /* Animated logo (same as login) */
        .logo-container {
            position: relative;
            width: 110px;
            height: 110px;
            margin: 0 auto 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .logo-border {
            position: absolute;
            width: 110px;
            height: 110px;
            border-radius: 50%;
            background: linear-gradient(45deg, #ff416c, #ff4b2b, #f9d423, #56ab2f, #1c92d2, #ff416c);
            background-size: 300% 300%;
            animation: rotateBorder 4s linear infinite;
            box-shadow: 0 0 25px rgba(255,75,43,0.8);
        }

        @keyframes rotateBorder {
            0% { transform: rotate(0deg); background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { transform: rotate(360deg); background-position: 0% 50%; }
        }

        .logo-mask {
            position: absolute;
            width: 98px;
            height: 98px;
            border-radius: 50%;
            background: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: inset 0 0 15px rgba(0,0,0,0.8);
        }

        .logo-box {
            width: 88px;
            height: 88px;
            border-radius: 50%;
            background: url('https://i.ibb.co/N6K9SJ1R/download.png') center/cover;
            border: 2px solid rgba(255,255,255,0.6);
            z-index: 2;
        }

        /* ===== ANIMATED RGB TITLE ===== */
        .register-title {
            text-align: center;
            font-size: 3.2rem;      /* bigger premium size */
            font-weight: 900;
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-bottom: 5px;
            background: linear-gradient(90deg, #ff416c, #ff4b2b, #f9d423, #56ab2f, #1c92d2, #ff416c);
            background-size: 300% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: rgbFlow 6s linear infinite;
            text-shadow: 0 0 20px rgba(255,75,43,0.3);
        }

        @keyframes rgbFlow {
            0% { background-position: 0% center; }
            100% { background-position: 200% center; }
        }

        .register-sub {
            text-align: center;
            color: #aaa;
            font-size: 1rem;
            margin-bottom: 30px;
            border-bottom: 1px dashed rgba(255,255,255,0.2);
            padding-bottom: 18px;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 20px;
            transform: translateY(-50%);
            color: rgba(255,255,255,0.8);
            font-size: 1.2rem;
            z-index: 2;
        }

        .password-wrapper {
            position: relative;
            width: 100%;
        }

        .form-control {
            background: rgba(10, 10, 10, 0.6);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 50px;
            padding-left: 52px;
            padding-right: 50px;
            height: 58px;
            color: white;
            font-size: 1rem;
            backdrop-filter: blur(4px);
            box-shadow: inset 0 5px 10px rgba(0,0,0,0.7);
            transition: 0.2s;
            width: 100%;
        }

        .form-control:focus {
            background: rgba(20, 20, 20, 0.8);
            border-color: #ff4b2b;
            box-shadow: 0 0 15px #ff4b2b, inset 0 2px 8px black;
            outline: none;
        }

        .form-control::placeholder {
            color: #aaa;
            font-weight: 300;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 20px;
            transform: translateY(-50%);
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            font-size: 1.3rem;
            z-index: 10;
            background: transparent;
            border: none;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toggle-password:hover {
            color: #ff4b2b;
            text-shadow: 0 0 8px #ff4b2b;
        }

        .btn-register {
            width: 100%;
            padding: 16px;
            border-radius: 60px;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            border: none;
            font-weight: 800;
            font-size: 1.3rem;
            color: white;
            text-shadow: 0 2px 5px black;
            margin-top: 15px;
            box-shadow: 0 10px 25px rgba(255,75,43,0.4);
            transition: 0.25s;
            letter-spacing: 1.5px;
        }

        .btn-register:hover {
            background: linear-gradient(135deg, #ff4b2b, #ff416c);
            transform: scale(1.02);
            box-shadow: 0 15px 35px #ff4b2b;
        }

        .login-link {
            margin-top: 22px;
            text-align: center;
        }
        .login-link a {
            color: #ccc;
            text-decoration: none;
            font-weight: 600;
            padding: 8px 25px;
            border-radius: 40px;
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.15);
            transition: 0.2s;
            display: inline-block;
            font-size: 0.95rem;
        }
        .login-link a:hover {
            background: rgba(255,75,43,0.2);
            color: white;
            border-color: #ff4b2b;
        }

        @media(max-width: 480px) {
            .register-card { width: 92%; padding: 30px 20px; }
            .register-title { font-size: 2.5rem; }
        }
    </style>
</head>
<body>

<!-- particles canvas -->
<div id="particles-js"></div>

<!-- Main content: register card (no sidebar) -->
<div class="page-container">
    <div class="main-content">
        <div class="register-card">
            <!-- Logo with animated border -->
            <div class="logo-container">
                <div class="logo-border"></div>
                <div class="logo-mask">
                    <div class="logo-box"></div>
                </div>
            </div>

            <!-- Large animated RGB title -->
            <div class="register-title">𝐑𝐄𝐆𝐈𝐒𝐓𝐄𝐑 𝐇𝐄𝐑𝐄</div>
            <div class="register-sub">Create Your Account Here</div>

            <form method="POST" action="">
                <!-- Username field -->
                <div class="form-group">
                    <i class="fa fa-user input-icon"></i>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>

                <!-- Password field with eye toggle -->
                <div class="form-group">
                    <i class="fa fa-lock input-icon"></i>
                    <div class="password-wrapper">
                        <input type="password" name="password" id="passwordField" class="form-control" placeholder="Password" required>
                        <i class="fa fa-eye toggle-password" id="togglePassword" onclick="togglePassword()"></i>
                    </div>
                </div>

                <!-- Referral code field -->
                <div class="form-group">
                    <i class="fa fa-gift input-icon"></i>
                    <input type="text" name="referral_code" class="form-control" placeholder="Referral Code" required>
                </div>

                <button type="submit" name="register" class="btn-register">
                    <i class="fa fa-user-plus"></i> REGISTER
                </button>

                <div class="login-link">
                    <a href="login.php"><i class="fa fa-sign-in-alt"></i> Already have an account?</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- particles initialization -->
<script>
    particlesJS('particles-js', {
        particles: {
            number: { value: 100, density: { enable: true, value_area: 1000 } },
            color: { value: ["#ff416c", "#ff4b2b", "#f9d423", "#56ab2f", "#1c92d2"] },
            shape: { type: ["circle", "triangle"] },
            opacity: { value: 0.6, random: true },
            size: { value: 4, random: true },
            line_linked: { enable: true, distance: 140, color: "#ffffff", opacity: 0.15 },
            move: { enable: true, speed: 2 }
        },
        interactivity: {
            events: { onhover: { enable: true, mode: "grab" } }
        }
    });

    // Password visibility toggle
    function togglePassword() {
        const passwordField = document.getElementById('passwordField');
        const toggleIcon = document.getElementById('togglePassword');
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }
</script>

<!-- optional Cloudflare beacon -->
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"2e3052dc8adf418cb4129f17c48fab46"}' crossorigin="anonymous"></script>

</body>
</html>