<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
include('conn.php');

// Get current user's role from session
$current_user = $_SESSION['username'];
$current_user_id = $_SESSION['user_id'] ?? 0;

// Fetch current user's role from database to be sure
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$current_user_id'");
$current_user_data = mysqli_fetch_assoc($user_query);
$is_owner = ($current_user_data['role'] == 'owner');

// Handle Delete User - Only owner can delete
if (isset($_GET['delete']) && $is_owner) {
    $delete_id = (int)$_GET['delete'];
    // Don't allow deleting yourself
    if ($delete_id != $current_user_id) {
        mysqli_query($conn, "DELETE FROM users WHERE id = $delete_id");
    }
    header("Location: manage_users.php");
    exit();
}

// Handle Edit User - Only owner can edit others
if (isset($_POST['edit_user']) && $is_owner) {
    $edit_id = (int)$_POST['user_id'];
    $status = (int)$_POST['status'];
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    
    mysqli_query($conn, "UPDATE users SET role = '$role', status = $status WHERE id = $edit_id");
    
    header("Location: manage_users.php");
    exit();
}

// Fetch users
$users = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users • VBOX</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: 'Montserrat', sans-serif;
    background: linear-gradient(120deg, #020617, #0f172a, #1e3a8a, #312e81);
    background-size: 400% 400%;
    animation: bg 18s ease infinite;
    color: #fff;
    overflow-x: hidden;
    min-height: 100vh;
}
@keyframes bg {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

#particles-js {
    position: fixed;
    inset: 0;
    z-index: -2;
}

/* GLASS EFFECT */
.glass, .glass-card, .modal-content, .sidebar-btn, header, .table-container {
    background: rgba(15, 23, 42, 0.7);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 22px;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
}

/* HEADER */
header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 60px;
    padding: 0 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 1000;
    background: rgba(15, 23, 42, 0.8);
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 0;
}
.menu-btn {
    font-size: 1.5rem;
    cursor: pointer;
    color: #ffd700;
    transition: all 0.3s ease;
}
.menu-btn:hover {
    transform: scale(1.1) rotate(90deg);
    color: #22d3ee;
}
.user-badge {
    background: rgba(255, 215, 0, 0.15);
    padding: 8px 20px;
    border-radius: 50px;
    display: flex;
    align-items: center;
    gap: 10px;
    border: 1px solid rgba(255, 215, 0, 0.3);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    transition: all 0.3s ease;
    cursor: pointer;
}
.user-badge:hover {
    background: rgba(255, 215, 0, 0.25);
    transform: scale(1.05);
    border-color: #ffd700;
}
.user-badge i {
    color: #ffd700;
    font-size: 1.1rem;
}
.user-badge span {
    font-weight: 600;
    color: #fff;
}

/* SIDEBAR */
#sidebar {
    position: fixed;
    top: 0;
    left: -280px;
    height: 100%;
    width: 260px;
    padding-top: 80px;
    transition: 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 1100;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
}
#sidebar.active {
    left: 0;
}

/* SIDEBAR LOGO */
.sidebar-logo {
    text-align: center;
    margin-bottom: 30px;
    padding: 0 15px;
}
.logo-container {
    width: 100px;
    height: 100px;
    margin: 0 auto 15px;
    position: relative;
    animation: float 3s ease-in-out infinite;
}
@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
}
.logo-glow {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
    border-radius: 50%;
    padding: 3px;
    animation: rotate 4s linear infinite;
}
@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.logo-inner {
    width: 100%;
    height: 100%;
    background: #1a1f2e;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: #ffd700;
    animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.7); }
    70% { box-shadow: 0 0 0 15px rgba(255, 215, 0, 0); }
    100% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0); }
}
.logo-text {
    font-size: 1.3rem;
    font-weight: 700;
    background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: rgbText 3s linear infinite;
}
@keyframes rgbText {
    0% { filter: hue-rotate(0deg); }
    50% { filter: hue-rotate(180deg); }
    100% { filter: hue-rotate(360deg); }
}
.admin-badge {
    background: linear-gradient(135deg, #ffd700, #ffa500);
    color: #000;
    padding: 5px 15px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
    margin-top: 5px;
    animation: glow 2s ease-in-out infinite;
}
@keyframes glow {
    0% { box-shadow: 0 0 5px #ffd700; }
    50% { box-shadow: 0 0 20px #ffd700; }
    100% { box-shadow: 0 0 5px #ffd700; }
}

.sidebar-btn {
    width: 90%;
    margin: 8px auto;
    padding: 12px 16px;
    border-radius: 16px;
    border: none;
    background: rgba(255, 255, 255, 0.08);
    color: #fff;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}
.sidebar-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
}
.sidebar-btn:hover::before {
    left: 100%;
}
.sidebar-btn i {
    width: 22px;
    text-align: center;
    color: #ffd700;
    transition: all 0.3s ease;
}
.sidebar-btn:hover {
    background: linear-gradient(135deg, #2563eb, #22d3ee);
    transform: translateX(8px);
    box-shadow: 0 5px 15px rgba(37, 99, 235, 0.3);
}
.sidebar-btn:hover i {
    color: #fff;
    transform: scale(1.1);
}

/* OVERLAY */
#overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    opacity: 0;
    pointer-events: none;
    transition: 0.3s;
    z-index: 1050;
}
#overlay.active {
    opacity: 1;
    pointer-events: auto;
}

/* MAIN CONTENT */
.main {
    padding: 90px 24px 24px;
    max-width: 1200px;
    margin: 0 auto;
    animation: fadeIn 0.5s ease;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* RGB TITLE */
.rgb-title {
    font-size: 2.5rem;
    font-weight: 700;
    text-align: center;
    margin: 20px 0 40px;
    animation: rgbTitle 3s linear infinite;
    text-transform: uppercase;
    letter-spacing: 3px;
}
@keyframes rgbTitle {
    0% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
    17% { color: #ff9933; text-shadow: 0 0 10px #ff8800; }
    33% { color: #ffff33; text-shadow: 0 0 10px #ffff00; }
    50% { color: #33ff33; text-shadow: 0 0 10px #00ff00; }
    67% { color: #33ccff; text-shadow: 0 0 10px #0099ff; }
    83% { color: #9933ff; text-shadow: 0 0 10px #8800ff; }
    100% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
}

/* PREMIUM TABLE */
.table-container {
    background: rgba(15, 23, 42, 0.5);
    backdrop-filter: blur(22px) saturate(180%);
    -webkit-backdrop-filter: blur(22px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 30px;
    padding: 25px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
    overflow-x: auto;
}

.premium-table {
    width: 100%;
    border-collapse: collapse;
    color: #fff;
}

/* GLASSY TABLE HEADER */
.premium-table thead tr {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

.premium-table th {
    background: rgba(255, 215, 0, 0.1);
    color: #ffd700;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 1px;
    padding: 18px 12px;
    border: none;
    position: relative;
    overflow: hidden;
}

.premium-table th::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { left: -100%; }
    20% { left: 100%; }
    100% { left: 100%; }
}

.premium-table th i {
    margin-right: 8px;
    color: #ffd700;
}

.premium-table td {
    padding: 16px 12px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    vertical-align: middle;
}

.premium-table tbody tr {
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.02);
}

.premium-table tbody tr:hover {
    background: rgba(255, 255, 255, 0.08);
    transform: scale(1.01);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

.premium-table .user-id {
    font-weight: 700;
    color: #ffd700;
}

.premium-table .username {
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
}

.premium-table .username i {
    color: #ffd700;
}

.role-badge {
    padding: 6px 14px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
}

.role-owner {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(255, 165, 0, 0.2));
    color: #ffd700;
    border: 1px solid rgba(255, 215, 0, 0.3);
}

.role-admin {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(37, 99, 235, 0.2));
    color: #93c5fd;
    border: 1px solid rgba(59, 130, 246, 0.3);
}

.role-user {
    background: linear-gradient(135deg, rgba(107, 114, 128, 0.2), rgba(75, 85, 99, 0.2));
    color: #d1d5db;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.status-badge {
    padding: 6px 14px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
}

.status-active {
    background: rgba(34, 197, 94, 0.15);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.3);
}

.status-blocked {
    background: rgba(239, 68, 68, 0.15);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.3);
}

/* ACTION BUTTONS - Only visible to owner */
.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.owner-only {
    display: <?= $is_owner ? 'flex' : 'none' ?>;
}

.btn-glass {
    padding: 8px 16px;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    cursor: pointer;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.btn-edit {
    background: rgba(34, 211, 238, 0.15);
    color: #7dd3fc;
    border: 1px solid rgba(34, 211, 238, 0.3);
}

.btn-edit:hover:not(:disabled) {
    background: rgba(34, 211, 238, 0.3);
    transform: scale(1.05);
    color: white;
}

.btn-delete {
    background: rgba(239, 68, 68, 0.15);
    color: #fca5a5;
    border: 1px solid rgba(239, 68, 68, 0.3);
}

.btn-delete:hover:not(:disabled) {
    background: rgba(239, 68, 68, 0.3);
    transform: scale(1.05);
    color: white;
}

.btn-glass:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

/* MODAL STYLES */
.modal-content {
    background: rgba(15, 23, 42, 0.95) !important;
    border: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.modal-header {
    border-bottom: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.modal-footer {
    border-top: 1px solid rgba(255, 215, 0, 0.2) !important;
}

.form-control, .form-select {
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #fff;
    border-radius: 12px;
    padding: 12px;
}

.form-control:focus, .form-select:focus {
    background: rgba(0, 0, 0, 0.5);
    border-color: #ffd700;
    box-shadow: 0 0 15px rgba(255, 215, 0, 0.3);
    color: #fff;
    outline: none;
}

/* BACK BUTTON */
.btn-back {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: white;
    padding: 12px 30px;
    border-radius: 50px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
    margin-top: 20px;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
}

.btn-back:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    color: white;
}

/* NO ACTIONS MESSAGE */
.no-actions {
    color: rgba(255, 255, 255, 0.4);
    font-style: italic;
    font-size: 0.85rem;
}

/* SCROLLBAR */
::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}
::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #ffd700, #22d3ee);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #22d3ee, #ffd700);
}

@media (max-width: 768px) {
    .rgb-title {
        font-size: 1.8rem;
    }
    .table-container {
        padding: 15px;
    }
    .premium-table th, .premium-table td {
        padding: 12px 8px;
        font-size: 0.85rem;
    }
}
</style>
</head>
<body>

<div id="particles-js"></div>
<div id="overlay" onclick="toggleSidebar()"></div>

<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <strong style="font-size:1.2rem;">User Management</strong>
    </div>
    
    <!-- USER BADGE - Only Username -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($_SESSION['username']) ?></span>
    </div>
</header>

<!-- SIDEBAR -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                <!-- Image Logo -->
                <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                     style="width:100px; height:100px; border-radius:50%;">
            </div>
        </div>
    </div>

        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($_SESSION['username']) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-edit"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<div class="main">
    
    <!-- RGB TITLE -->
    <div class="rgb-title">
        <i class="fas fa-users me-3"></i>MANAGE USERS
    </div>

    <!-- PREMIUM TABLE -->
    <div class="table-container">
        <table class="premium-table">
            <thead>
                <tr>
                    <th><i class="fas fa-hashtag"></i> ID</th>
                    <th><i class="fas fa-user"></i> Username</th>
                    <th><i class="fas fa-envelope"></i> Email</th>
                    <th><i class="fas fa-tag"></i> Role</th>
                    <th><i class="fas fa-circle"></i> Status</th>
                    <?php if($is_owner): ?>
                    <th><i class="fas fa-cog"></i> Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php while($user = mysqli_fetch_assoc($users)): 
                    $is_self = ($user['id'] == $current_user_id);
                ?>
                <tr>
                    <td><span class="user-id">#<?= $user['id'] ?></span></td>
                    <td>
                        <div class="username">
                            <i class="fas fa-user-circle"></i>
                            <?= htmlspecialchars($user['username']) ?>
                            <?php if($is_self): ?>
                                <span class="badge bg-info ms-2">You</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td><?= htmlspecialchars($user['email'] ?? '—') ?></td>
                    <td>
                        <?php 
                        $role = $user['role'] ?? 'user';
                        $roleClass = 'role-' . $role;
                        $roleIcon = $role == 'owner' ? 'fa-crown' : ($role == 'admin' ? 'fa-shield-alt' : 'fa-user');
                        ?>
                        <span class="role-badge <?= $roleClass ?>">
                            <i class="fas <?= $roleIcon ?>"></i>
                            <?= strtoupper($role) ?>
                        </span>
                    </td>
                    <td>
                        <?php if($user['status'] ?? 1): ?>
                            <span class="status-badge status-active">
                                <i class="fas fa-check-circle"></i> ACTIVE
                            </span>
                        <?php else: ?>
                            <span class="status-badge status-blocked">
                                <i class="fas fa-ban"></i> BLOCKED
                            </span>
                        <?php endif; ?>
                    </td>
                    
                    <?php if($is_owner): ?>
                    <td>
                        <div class="action-buttons">
                            <!-- Edit Button - Only for owner and not self -->
                            <?php if(!$is_self): ?>
                            <button class="btn-glass btn-edit" 
                                    onclick="openEditModal(<?= $user['id'] ?>, '<?= $user['username'] ?>', '<?= $user['email'] ?>', '<?= $user['role'] ?? 'user' ?>', <?= $user['status'] ?? 1 ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            
                            <!-- Delete Button - Only for owner and not self -->
                            <a href="?delete=<?= $user['id'] ?>" class="btn-glass btn-delete" onclick="return confirmDelete('<?= addslashes($user['username']) ?>')">
                                <i class="fas fa-trash-alt"></i> Delete
                            </a>
                            <?php else: ?>
                            <span class="no-actions">—</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Back Button -->
        <div class="text-center mt-4">
            <a href="dashboard.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
</div>

<!-- EDIT USER MODAL - Only for owner -->
<?php if($is_owner): ?>
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content glass">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2" style="color:#ffd700;"></i>
                    Edit User
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" id="edit_username" readonly disabled>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" readonly disabled>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-select" id="edit_role">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                            <option value="owner">Owner</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" id="edit_status">
                            <option value="1">ACTIVE</option>
                            <option value="0">BLOCKED</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit_user" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Sidebar functions
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('active');
}

// Close sidebar when clicking outside
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.querySelector('.menu-btn');
    const overlay = document.getElementById('overlay');
    
    if (!sidebar.contains(e.target) && !menuBtn.contains(e.target) && sidebar.classList.contains('active')) {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }
});

// Particles
particlesJS("particles-js", {
    particles: {
        number: { value: 60 },
        color: { value: "#ffffff" },
        opacity: { value: 0.4 },
        size: { value: 2 },
        move: { 
            enable: true,
            speed: 0.8,
            direction: "bottom",
            random: true
        }
    }
});

// Edit modal function - Only works if owner
<?php if($is_owner): ?>
function openEditModal(id, username, email, role, status) {
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_username').value = username;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_status').value = status;
    
    new bootstrap.Modal(document.getElementById('editUserModal')).show();
}
<?php endif; ?>

// Delete confirmation
function confirmDelete(username) {
    return confirm(`⚠️ Are you sure you want to delete user "${username}"?\nThis action cannot be undone!`);
}

// Auto close overlay
document.getElementById('overlay').onclick = function() {
    document.getElementById('sidebar').classList.remove('active');
    document.getElementById('overlay').classList.remove('active');
};
</script>

</body>
</html>