<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
include('conn.php');

// Update license
if(isset($_POST['update'])){
    $id = intval($_POST['id']);
    $license_key = mysqli_real_escape_string($conn, $_POST['license_key']);
    $expiry_date = $_POST['expiry_date'];
    $status = intval($_POST['status']);
    $package_name = mysqli_real_escape_string($conn, $_POST['package_name']);

    mysqli_query($conn, "UPDATE licenses SET 
        license_key='$license_key', 
        expiry_date='$expiry_date', 
        status=$status,
        package_name='$package_name'
        WHERE id=$id");

    header('Location: edit_license.php');
    exit;
}

// Fetch license
$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM licenses WHERE id=$id");
if(mysqli_num_rows($result) == 0){
    echo "License not found!";
    exit;
}
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit License - VIP Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #1f1c2c, #928dab);
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            padding: 40px 20px;
        }
        .edit-card {
            background-color: #2c2f4a;
            border-radius: 16px;
            padding: 30px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        }
        .edit-card h2 {
            background: linear-gradient(to right, #ff416c, #ff4b2b);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
            margin-bottom: 30px;
            text-align: center;
        }
        label {
            color: #bbb;
            font-weight: 500;
        }
        .form-control {
            border-radius: 10px;
            border: none;
            box-shadow: inset 0 0 5px rgba(255,255,255,0.1);
        }
        .btn-success {
            background: linear-gradient(to right, #00c9ff, #92fe9d);
            border: none;
            font-weight: 600;
        }
        .btn-secondary {
            background-color: #444;
            border: none;
            font-weight: 500;
        }
        .btn {
            border-radius: 10px;
        }
        .readonly-field {
            background-color: #444;
            color: #ddd;
        }

        /* Sidebar CSS */
        #sidebar {
            position: fixed;
            top: 0;
            right: -260px;
            height: 100%;
            width: 260px;
            background: rgba(40, 40, 60, 0.95);
            backdrop-filter: blur(8px);
            padding-top: 20px;
            transition: right 0.3s ease;
            z-index: 9999;
            border-left: 1px solid #555;
        }
        #sidebar.active { right: 0; }
        .sidebar-header {
            text-align: center;
            margin-bottom: 25px;
        }
        .vip-icon-box {
            width: 50px;
            height: 50px;
            margin: 0 auto;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            border-radius: 12px;
            box-shadow: 0 8px 15px rgba(255, 65, 108, 0.4);
        }
        .sidebar-title {
            margin-top: 10px;
            font-size: 1.2rem;
            font-weight: bold;
            color: #ffdfdf;
        }
        .sidebar-btn {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid #6c757d;
            color: #fff;
            text-align: center;
            width: 80%;
            margin: 10px auto;
            padding: 10px 15px;
            font-size: 0.95rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 3px 6px rgba(0,0,0,0.2);
            display: block;
        }
        .sidebar-btn:hover {
            background-color: #6c757d;
            transform: scale(1.03);
        }
        .hamburger {
            cursor: pointer;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 20px;
            height: 14px;
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
        }
        .hamburger span {
            display: block;
            height: 2.5px;
            background-color: white;
            border-radius: 2px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div id="sidebar">
    <div class="sidebar-header">
        <div class="vip-icon-box"></div>
        <div class="sidebar-title">VIP Panel</div>
    </div>
    <button class="sidebar-btn" onclick="location.href='dashboard.php'">Dashboard</button>
    <button class="sidebar-btn" onclick="location.href='license_check_ui.php'">Check Licenses</button>
    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">Generate License</button>
    <button class="sidebar-btn" onclick="location.href='edit_license.php'">Edit License</button>
    <button class="sidebar-btn" onclick="location.href='manage_users.php'">Manage Users</button>
    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">Manage Referrals</button>
    <button class="sidebar-btn" onclick="location.href='manage_packaes.php'">Packaes Edit</button>
    <button class="sidebar-btn" onclick="location.href='logout.php'">Logout</button>
</div>

<div class="hamburger" onclick="toggleSidebar()">
    <span></span>
    <span></span>
    <span></span>
</div>

<div class="edit-card">
    <h2>Edit License</h2>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">

        <div class="mb-3">
            <label>License Key</label>
            <input type="text" name="license_key" class="form-control" value="<?= htmlspecialchars($row['license_key']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Expiry Date</label>
            <input type="datetime-local" name="expiry_date" class="form-control"
                   value="<?= date('Y-m-d\TH:i', strtotime($row['expiry_date'])) ?>" required>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control">
                <option value="1" <?= $row['status'] ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= !$row['status'] ? 'selected' : '' ?>>Blocked</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Package Name</label>
            <input type="text" name="package_name" class="form-control"
                   value="<?= htmlspecialchars($row['package_name']) ?>" required>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" name="update" class="btn btn-success">Update License</button>
            <a href="edit_license.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}
document.addEventListener('click', function(e) {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.querySelector('.hamburger');
    if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('active');
    }
});
</script>

</body>
</html>
