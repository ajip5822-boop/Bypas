<?php
session_start();
include("conn.php");

// ============================================
// CHECK IF USER IS LOGGED IN
// ============================================
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$current_user = $_SESSION['username'] ?? 'Guest';

/* ================= HANDLE GENERATE ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $package = trim($_POST['package_name'] ?? '');
    $key_type = $_POST['key_type'] ?? 'auto';
    $custom_key = trim($_POST['custom_key'] ?? '');
    
    // Handle expiry based on key type
    if ($key_type === 'custom' && isset($_POST['custom_date']) && !empty($_POST['custom_date'])) {
        // Custom date for custom key
        $expiry = $_POST['custom_date'];
        $days = 'custom';
    } else {
        // Duration based for auto key
        $expiry_duration = $_POST['expiry_duration'] ?? '30';
        $days = intval($expiry_duration);
        $expiry = date('Y-m-d', strtotime("+$days days"));
    }

    if ($package !== '' && $expiry !== '') {

        // Generate or use custom key
        if ($key_type === 'custom' && !empty($custom_key)) {
            $license = strtoupper($custom_key);
        } else {
            $license = strtoupper('RIYAZ-' . bin2hex(random_bytes(4)) . '-' . rand(100, 999));
        }

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO licenses (license_key, expiry_date, status, package_name)
             VALUES (?, ?, 1, ?)"
        );
        mysqli_stmt_bind_param($stmt, "sss", $license, $expiry, $package);
        mysqli_stmt_execute($stmt);

        $_SESSION['success_license'] = [
            'package' => $package,
            'license' => $license,
            'expiry'  => $expiry,
            'days'    => $days,
            'key_type' => $key_type,
            'status'  => 'ACTIVE'
        ];

        header("Location: generate_ui.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Generate License</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
    margin:0;
    font-family:'Montserrat',sans-serif;
    color:#fff;
    background:linear-gradient(120deg,#020617,#0f172a,#1e3a8a,#312e81,#020617);
    background-size:400% 400%;
    animation:bg 18s ease infinite;
    min-height:100vh;
}
@keyframes bg{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
}

/* PARTICLES */
#particles-js{
    position:fixed;
    inset:0;
    z-index:-1;
}

/* GLASS EFFECT */
.glass{
    background:rgba(15,23,42,.75);
    backdrop-filter:blur(22px) saturate(180%);
    -webkit-backdrop-filter:blur(22px) saturate(180%);
    border:1px solid rgba(255,255,255,.18);
    border-radius:22px;
    box-shadow:0 20px 50px rgba(0,0,0,.45);
}

/* HEADER */
header{
    position:fixed;
    top:0;
    left:0;
    right:0;
    height:60px;
    padding:0 20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    z-index:1000;
    background:rgba(15,23,42,.8);
    backdrop-filter:blur(22px) saturate(180%);
    -webkit-backdrop-filter:blur(22px) saturate(180%);
    border-bottom:1px solid rgba(255,255,255,.18);
}
.menu-btn{
    cursor:pointer;
    font-size:22px;
    color:#ffd700;
    transition:all 0.3s ease;
}
.menu-btn:hover{
    transform:scale(1.1) rotate(90deg);
    color:#22d3ee;
}
.user-badge{
    background:rgba(255,215,0,0.15);
    padding:8px 20px;
    border-radius:50px;
    display:flex;
    align-items:center;
    gap:10px;
    border:1px solid rgba(255,215,0,0.3);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    transition:all 0.3s ease;
    cursor:pointer;
}
.user-badge:hover{
    background:rgba(255,215,0,0.25);
    transform:scale(1.05);
    border-color:#ffd700;
}
.user-badge i{
    color:#ffd700;
    font-size:1.1rem;
}
.user-badge span{
    font-weight:600;
    color:#fff;
}

/* SIDEBAR */
#sidebar{
    position:fixed;
    top:0;
    left:-280px;
    width:260px;
    height:100%;
    padding-top:80px;
    transition:0.35s cubic-bezier(0.4,0,0.2,1);
    z-index:1100;
    background:rgba(15,23,42,.95);
    backdrop-filter:blur(22px) saturate(180%);
    -webkit-backdrop-filter:blur(22px) saturate(180%);
    border-right:1px solid rgba(255,255,255,.18);
}
#sidebar.active{
    left:0;
}

/* SIDEBAR LOGO */
.sidebar-logo{
    text-align:center;
    margin-bottom:30px;
    padding:0 15px;
}
.logo-container{
    width:100px;
    height:100px;
    margin:0 auto 15px;
    position:relative;
    animation:float 3s ease-in-out infinite;
}
@keyframes float{
    0%{transform:translateY(0px);}
    50%{transform:translateY(-10px);}
    100%{transform:translateY(0px);}
}
.logo-glow{
    width:100%;
    height:100%;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    border-radius:50%;
    padding:3px;
    animation:rotate 4s linear infinite;
}
@keyframes rotate{
    from{transform:rotate(0deg);}
    to{transform:rotate(360deg);}
}
.logo-inner{
    width:100%;
    height:100%;
    background:#1a1f2e;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:2.5rem;
    color:#ffd700;
    animation:pulse 2s ease-in-out infinite;
}
@keyframes pulse{
    0%{box-shadow:0 0 0 0 rgba(255,215,0,0.7);}
    70%{box-shadow:0 0 0 15px rgba(255,215,0,0);}
    100%{box-shadow:0 0 0 0 rgba(255,215,0,0);}
}
.logo-text{
    font-size:1.3rem;
    font-weight:700;
    background:linear-gradient(135deg,#ffd700,#22d3ee,#ffd700);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    animation:rgbText 3s linear infinite;
}
@keyframes rgbText{
    0%{filter:hue-rotate(0deg);}
    50%{filter:hue-rotate(180deg);}
    100%{filter:hue-rotate(360deg);}
}
.admin-badge{
    background:linear-gradient(135deg,#ffd700,#ffa500);
    color:#000;
    padding:5px 15px;
    border-radius:50px;
    font-size:0.8rem;
    font-weight:600;
    display:inline-block;
    margin-top:5px;
    animation:glow 2s ease-in-out infinite;
}
@keyframes glow{
    0%{box-shadow:0 0 5px #ffd700;}
    50%{box-shadow:0 0 20px #ffd700;}
    100%{box-shadow:0 0 5px #ffd700;}
}

.sidebar-btn{
    width:90%;
    margin:8px auto;
    padding:12px 16px;
    border-radius:16px;
    border:none;
    background:rgba(255,255,255,.08);
    color:#fff;
    display:flex;
    align-items:center;
    gap:12px;
    transition:all 0.3s cubic-bezier(0.4,0,0.2,1);
    position:relative;
    overflow:hidden;
}
.sidebar-btn::before{
    content:'';
    position:absolute;
    top:0;
    left:-100%;
    width:100%;
    height:100%;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent);
    transition:left 0.5s ease;
}
.sidebar-btn:hover::before{
    left:100%;
}
.sidebar-btn i{
    width:22px;
    text-align:center;
    color:#ffd700;
    transition:all 0.3s ease;
}
.sidebar-btn:hover{
    background:linear-gradient(135deg,#2563eb,#22d3ee);
    transform:translateX(8px);
    box-shadow:0 5px 15px rgba(37,99,235,0.3);
}
.sidebar-btn:hover i{
    color:#fff;
    transform:scale(1.1);
}

/* OVERLAY */
#overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    opacity:0;
    pointer-events:none;
    transition:.3s;
    z-index:1050;
}
#overlay.active{
    opacity:1;
    pointer-events:auto;
}

/* MAIN */
.main{
    padding:90px 16px;
    display:flex;
    justify-content:center;
    animation:fadeIn 0.5s ease;
}
@keyframes fadeIn{
    from{opacity:0;transform:translateY(20px);}
    to{opacity:1;transform:translateY(0);}
}
.form-card{
    width:100%;
    max-width:450px;
    padding:30px;
    animation:cardFloat 3s ease-in-out infinite;
}
@keyframes cardFloat{
    0%{transform:translateY(0px);}
    50%{transform:translateY(-5px);}
    100%{transform:translateY(0px);}
}

/* RGB TITLE */
.rgb-title{
    font-size:1.8rem;
    font-weight:700;
    text-align:center;
    margin-bottom:25px;
    animation:rgbTitle 3s linear infinite;
}
@keyframes rgbTitle{
    0%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
    17%{color:#ff9933;text-shadow:0 0 10px #ff8800;}
    33%{color:#ffff33;text-shadow:0 0 10px #ffff00;}
    50%{color:#33ff33;text-shadow:0 0 10px #00ff00;}
    67%{color:#33ccff;text-shadow:0 0 10px #0099ff;}
    83%{color:#9933ff;text-shadow:0 0 10px #8800ff;}
    100%{color:#ff3333;text-shadow:0 0 10px #ff0000;}
}

/* INPUT */
.form-control, .form-select, .form-date{
    background:rgba(255,255,255,.08);
    border:1px solid rgba(255,255,255,.2);
    color:#fff;
    border-radius:14px;
    padding:14px;
    transition:all 0.3s ease;
    width:100%;
}
.form-control:focus, .form-select:focus, .form-date:focus{
    background:rgba(255,255,255,.15);
    border-color:#ffd700;
    box-shadow:0 0 20px rgba(255,215,0,0.3);
    outline:none;
}
.form-select option{
    background:#1a2634;
    color:#fff;
}
.form-date::-webkit-calendar-picker-indicator{
    filter:invert(1);
    cursor:pointer;
}

/* TOGGLE SWITCH */
.toggle-container{
    display:flex;
    align-items:center;
    justify-content:space-between;
    background:rgba(255,255,255,.05);
    border-radius:50px;
    padding:5px;
    margin:20px 0;
    border:1px solid rgba(255,255,255,.1);
    animation:glowBorder 2s ease-in-out infinite;
}
@keyframes glowBorder{
    0%{border-color:rgba(255,215,0,0.3);}
    50%{border-color:rgba(34,211,238,0.6);}
    100%{border-color:rgba(255,215,0,0.3);}
}
.toggle-option{
    flex:1;
    text-align:center;
    padding:12px;
    border-radius:50px;
    cursor:pointer;
    transition:all 0.3s ease;
}
.toggle-option.active{
    background:linear-gradient(135deg,#2563eb,#22d3ee);
    animation:pulseGlow 2s infinite;
}
@keyframes pulseGlow{
    0%{box-shadow:0 0 5px #2563eb;}
    50%{box-shadow:0 0 20px #22d3ee;}
    100%{box-shadow:0 0 5px #2563eb;}
}
.toggle-option i{
    margin-right:5px;
}

/* CUSTOM KEY CONTAINER */
.custom-key-container{
    display:none;
    margin-bottom:15px;
    animation:slideDown 0.3s ease;
}
.custom-key-container.active{
    display:block;
}
@keyframes slideDown{
    from{opacity:0;transform:translateY(-10px);}
    to{opacity:1;transform:translateY(0);}
}

/* AUTO KEY PREVIEW - MASKED */
.auto-key-preview{
    background:rgba(34,211,238,.1);
    border:1px dashed rgba(34,211,238,.3);
    border-radius:14px;
    padding:20px;
    margin:15px 0;
    text-align:center;
    animation:rgbBorder 3s linear infinite;
}
@keyframes rgbBorder{
    0%{border-color:#ff0000;}
    33%{border-color:#00ff00;}
    66%{border-color:#0000ff;}
    100%{border-color:#ff0000;}
}
.auto-key-preview i{
    color:#22d3ee;
    margin-right:5px;
    animation:rotate 3s linear infinite;
}
.auto-key-preview .masked-key{
    color:#22d3ee;
    font-weight:700;
    font-size:1.3rem;
    letter-spacing:3px;
    font-family:monospace;
    animation:rgbText 3s linear infinite;
}
.auto-key-preview .format-text{
    color:rgba(255,255,255,.5);
    font-size:0.8rem;
    margin-top:8px;
}

/* DURATION SELECT - AUTO MODE */
.duration-container{
    display:block;
}
.duration-container.hidden{
    display:none;
}

.duration-select{
    background:rgba(255,255,255,.08);
    border:1px solid rgba(255,255,255,.2);
    color:#fff;
    border-radius:14px;
    padding:14px;
    width:100%;
    margin:10px 0;
    cursor:pointer;
    transition:all 0.3s ease;
}
.duration-select:hover{
    border-color:#22d3ee;
    transform:scale(1.02);
}

/* CUSTOM DATE CONTAINER */
.custom-date-container{
    display:none;
    margin:15px 0;
    animation:slideDown 0.3s ease;
}
.custom-date-container.active{
    display:block;
}

/* PREVIEW DATE */
.preview-date{
    background:rgba(34,211,238,.1);
    border:1px dashed rgba(34,211,238,.3);
    border-radius:14px;
    padding:15px;
    margin:15px 0;
    text-align:center;
    animation:glow 2s ease-in-out infinite;
}
.preview-date i{
    color:#22d3ee;
    margin-right:5px;
    animation:rotate 3s linear infinite;
}
.preview-date strong{
    color:#22d3ee;
    font-size:1.2rem;
    font-weight:700;
}

/* BUTTON */
.btn-ios{
    border:none;
    border-radius:16px;
    padding:16px;
    font-weight:700;
    background:linear-gradient(135deg,#2563eb,#22d3ee);
    color:#fff;
    transition:all 0.3s ease;
    position:relative;
    overflow:hidden;
    width:100%;
}
.btn-ios::before{
    content:'';
    position:absolute;
    top:0;
    left:-100%;
    width:100%;
    height:100%;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.3),transparent);
    transition:left 0.5s ease;
}
.btn-ios:hover::before{
    left:100%;
}
.btn-ios:hover{
    transform:translateY(-3px);
    box-shadow:0 15px 30px rgba(37,99,235,0.4);
}
.btn-ios:active{
    transform:translateY(0);
}

/* SUCCESS POPUP */
.success-overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    backdrop-filter:blur(14px);
    -webkit-backdrop-filter:blur(14px);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:2000;
}
.success-overlay.active{
    display:flex;
}
.success-card{
    width:90%;
    max-width:360px;
    padding:26px;
    text-align:center;
    animation:popupIn .45s cubic-bezier(.2,1.4,.4,1);
}
@keyframes popupIn{
    from{transform:scale(.85);opacity:0}
    to{transform:scale(1);opacity:1}
}

.success-row{
    display:flex;
    justify-content:space-between;
    padding:12px 0;
    border-bottom:1px solid rgba(255,255,255,.15);
    animation:slideIn 0.3s ease;
}
@keyframes slideIn{
    from{opacity:0;transform:translateX(-10px);}
    to{opacity:1;transform:translateX(0);}
}

/* COPY TOAST */
#toast{
    position:fixed;
    bottom:40px;
    left:50%;
    transform:translateX(-50%) translateY(20px);
    background:linear-gradient(135deg,#10b981,#059669);
    backdrop-filter:blur(10px);
    -webkit-backdrop-filter:blur(10px);
    padding:12px 24px;
    border-radius:50px;
    opacity:0;
    transition:.35s;
    z-index:3000;
    box-shadow:0 10px 25px rgba(16,185,129,0.3);
}
#toast.show{
    opacity:1;
    transform:translateX(-50%) translateY(0);
}

/* GENERATE BUTTON */
.generate-btn{
    margin-top:20px;
}

/* SCROLLBAR */
::-webkit-scrollbar {
    width: 8px;
}
::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg,#ffd700,#22d3ee);
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg,#22d3ee,#ffd700);
}
</style>
</head>

<body>

<div id="particles-js"></div>

<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <h4 class="mb-0 rgb-title" style="font-size:1.2rem; margin:0;">Generate License</h4>
    </div>
    
    <!-- USER BADGE -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($current_user) ?></span>
    </div>
</header>

<div id="overlay" onclick="closeSidebar()"></div>

<!-- SIDEBAR WITH LOGO -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                    <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                         style="width:100px; height:100px; border-radius:50%;">
                </div>
            </div>
        </div>
        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($current_user) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-cog"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<div class="main">
    <div class="glass form-card">
        <div class="rgb-title">🔑 GENERATE LICENSE</div>

        <form method="POST" id="licenseForm">
            <div class="mb-3">
                <label><i class="fas fa-box me-2" style="color:#ffd700;"></i>Package Name</label>
                <input name="package_name" class="form-control" placeholder="e.g., com.example.app" required>
            </div>

            <!-- Key Type Toggle -->
            <div class="toggle-container">
                <div class="toggle-option active" id="autoToggle" onclick="setKeyType('auto')">
                    <i class="fas fa-random"></i> Auto
                </div>
                <div class="toggle-option" id="customToggle" onclick="setKeyType('custom')">
                    <i class="fas fa-pencil-alt"></i> Custom
                </div>
            </div>

            <input type="hidden" name="key_type" id="keyType" value="auto">

            <!-- Auto Generate Preview - MASKED -->
            <div class="auto-key-preview" id="autoPreview">
                <i class="fas fa-key"></i>
                <div class="masked-key" id="maskedKey">RIAYZ-XXXX-XXXX</div>
                <div class="format-text">
                    <i class="fas fa-info-circle"></i> Format: RIYAZ-XXXX-XXX
                </div>
            </div>

            <!-- Custom Key Input -->
            <div class="custom-key-container" id="customKeyContainer">
                <label><i class="fas fa-key me-2" style="color:#ffd700;"></i>Enter Custom Key</label>
                <input type="text" name="custom_key" class="form-control" placeholder="Enter your license key...">
            </div>

            <!-- AUTO MODE - Duration Dropdown -->
            <div class="duration-container" id="durationContainer">
                <label><i class="fas fa-clock me-2" style="color:#ffd700;"></i>Expiry Duration</label>
                <select name="expiry_duration" id="expiryDuration" class="duration-select" onchange="updateAutoPreview()">
                    <option value="1">1 Day</option>
                    <option value="3">3 Days</option>
                    <option value="7">7 Days</option>
                    <option value="30" selected>30 Days</option>
                    <option value="60">60 Days</option>
                    <option value="90">90 Days</option>
                    <option value="180">180 Days</option>
                    <option value="365">365 Days (1 Year)</option>
                </select>
                <!-- Auto Preview Date -->
                <div class="preview-date" id="autoPreviewDate">
                    <i class="fas fa-calendar-check"></i>
                    Expires: <strong id="autoExpiryPreview"><?=date('Y-m-d', strtotime('+30 days'))?></strong>
                </div>
            </div>

            <!-- CUSTOM MODE - Custom Date Picker -->
            <div class="custom-date-container" id="customDateContainer">
                <label><i class="fas fa-calendar-alt me-2" style="color:#ffd700;"></i>Expiry Date</label>
                <input type="date" name="custom_date" id="customDate" class="form-date" min="<?=date('Y-m-d')?>" value="<?=date('Y-m-d', strtotime('+30 days'))?>">
                <small class="text-muted d-block mt-1">Select custom expiry date</small>
            </div>

            <div class="d-grid generate-btn">
                <button class="btn-ios" name="generate">
                    <i class="fas fa-magic me-2"></i>Generate License
                </button>
            </div>
        </form>
    </div>
</div>

<?php if(isset($_SESSION['success_license'])):
$s=$_SESSION['success_license']; ?>
<div class="success-overlay active" id="successModal">
    <div class="success-card glass">
        <i class="fas fa-check-circle fa-3x mb-3" style="color:#10b981;"></i>
        <h4 class="mb-3">License Generated!</h4>

        <div class="success-row"><span>Package</span><strong><?=htmlspecialchars($s['package'])?></strong></div>
        <div class="success-row"><span>License</span><strong id="copyKey"><?=htmlspecialchars($s['license'])?></strong></div>
        <div class="success-row"><span>Expiry</span><strong><?=htmlspecialchars($s['expiry'])?></strong></div>
        <div class="success-row"><span>Duration</span><strong><?=($s['days'] == 'custom' ? 'Custom Date' : $s['days'].' days')?></strong></div>
        <div class="success-row"><span>Key Type</span><strong><?=$s['key_type']?></strong></div>
        <div class="success-row"><span>Status</span><strong class="text-success"><?=$s['status']?></strong></div>

        <div class="d-grid gap-2 mt-4">
            <button class="btn-ios" onclick="copyKey()">
                <i class="far fa-copy me-2"></i>Copy License
            </button>
            <button class="btn btn-outline-light" onclick="closeSuccess()">
                <i class="fas fa-check me-2"></i>OK
            </button>
        </div>
    </div>
</div>
<?php unset($_SESSION['success_license']); endif; ?>

<div id="toast">✅ License Copied!</div>

<script>
/* SIDEBAR */
const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");

function toggleSidebar() {
    sidebar.classList.toggle("active");
    overlay.classList.toggle("active");
}

function closeSidebar() {
    sidebar.classList.remove("active");
    overlay.classList.remove("active");
}

/* KEY TYPE TOGGLE */
function setKeyType(type) {
    document.getElementById('keyType').value = type;
    
    const autoToggle = document.getElementById('autoToggle');
    const customToggle = document.getElementById('customToggle');
    const autoPreview = document.getElementById('autoPreview');
    const customContainer = document.getElementById('customKeyContainer');
    const durationContainer = document.getElementById('durationContainer');
    const customDateContainer = document.getElementById('customDateContainer');
    
    if (type === 'auto') {
        autoToggle.classList.add('active');
        customToggle.classList.remove('active');
        autoPreview.style.display = 'block';
        customContainer.classList.remove('active');
        durationContainer.classList.remove('hidden');
        customDateContainer.classList.remove('active');
    } else {
        autoToggle.classList.remove('active');
        customToggle.classList.add('active');
        autoPreview.style.display = 'none';
        customContainer.classList.add('active');
        durationContainer.classList.add('hidden');
        customDateContainer.classList.add('active');
    }
}

/* UPDATE AUTO PREVIEW DATE */
function updateAutoPreview() {
    const days = document.getElementById('expiryDuration').value;
    const today = new Date();
    const expiryDate = new Date(today);
    expiryDate.setDate(today.getDate() + parseInt(days));
    
    const year = expiryDate.getFullYear();
    const month = String(expiryDate.getMonth() + 1).padStart(2, '0');
    const day = String(expiryDate.getDate()).padStart(2, '0');
    
    document.getElementById('autoExpiryPreview').textContent = `${year}-${month}-${day}`;
}

/* AUTO PREVIEW - MASKED */
function refreshAutoPreview() {
    const maskedElement = document.getElementById('maskedKey');
    const patterns = [
        'RIYAZ-XXXX-DRE',
        'DN04-XXXX-D543',
        'DNORY-XXXX-XXXX-D98J'
    ];
    const randomIndex = Math.floor(Math.random() * patterns.length);
    maskedElement.textContent = patterns[randomIndex];
}
setInterval(refreshAutoPreview, 3000);

/* SUCCESS MODAL */
function closeSuccess() {
    document.getElementById("successModal").classList.remove("active");
}

/* COPY FUNCTION */
function copyKey() {
    const text = document.getElementById("copyKey").innerText;
    navigator.clipboard.writeText(text).then(() => {
        const toast = document.getElementById("toast");
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 2000);
    });
}

/* PARTICLES */
particlesJS("particles-js", {
    particles: {
        number: { value: 70 },
        color: { value: "#ffffff" },
        opacity: { value: 0.4 },
        size: { value: 2 },
        move: { speed: 1, direction: "bottom" }
    }
});

// Initialize
window.onload = function() {
    updateAutoPreview();
    refreshAutoPreview();
    setKeyType('auto'); // Default to auto mode
};
</script>

</body>
</html>