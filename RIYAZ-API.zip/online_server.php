<?php
include 'conn.php';
session_start();

// ============================================
// OWNER ACCESS ONLY - Check if logged in user is RIYAZOWNER
// ============================================

// First check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get current user details
$user_id = $_SESSION['user_id'];
$user_query = $conn->query("SELECT username FROM users WHERE id = $user_id");
$user_data = $user_query->fetch_assoc();
$current_user = $user_data['username'];

// Check if user is RIYAZOWNER
if ($current_user !== 'RIYAZOWNER') {
    // Not owner - show access denied page
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Access Denied • VBOX</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body {
                font-family: 'Montserrat', Arial, sans-serif;
                background: linear-gradient(135deg, #020617, #0f172a, #1e3a8a, #312e81);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
                margin: 0;
                padding: 20px;
            }
            .access-denied-card {
                background: rgba(239, 68, 68, 0.1);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border: 1px solid rgba(239, 68, 68, 0.3);
                border-radius: 30px;
                padding: 40px;
                max-width: 500px;
                text-align: center;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
                animation: shake 0.5s ease;
            }
            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }
            .lock-icon {
                font-size: 5rem;
                color: #ef4444;
                margin-bottom: 20px;
                animation: pulse 2s infinite;
            }
            @keyframes pulse {
                0% { transform: scale(1); opacity: 1; }
                50% { transform: scale(1.1); opacity: 0.8; }
                100% { transform: scale(1); opacity: 1; }
            }
            h2 {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 15px;
                background: linear-gradient(135deg, #ef4444, #f87171);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }
            .user-name {
                background: rgba(255, 255, 255, 0.1);
                padding: 10px 20px;
                border-radius: 50px;
                display: inline-block;
                margin: 20px 0;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            .user-name i {
                color: #ffd700;
                margin-right: 8px;
            }
            .btn-back {
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                color: white;
                padding: 12px 30px;
                border-radius: 50px;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 10px;
                transition: all 0.3s ease;
                margin-top: 20px;
            }
            .btn-back:hover {
                background: rgba(255, 255, 255, 0.2);
                transform: translateY(-3px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            }
            .owner-badge {
                background: linear-gradient(135deg, #ffd700, #ffa500);
                color: #000;
                padding: 5px 15px;
                border-radius: 50px;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 5px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="access-denied-card">
            <div class="lock-icon">
                <i class="fas fa-lock"></i>
            </div>
            <div class="owner-badge">
                <i class="fas fa-crown"></i> OWNER ONLY
            </div>
            <h2>Access Denied!</h2>
            <p style="margin-bottom: 20px; opacity: 0.9;">This area is restricted to the owner only.</p>
            
            <div class="user-name">
                <i class="fas fa-user"></i> Your Username: <strong><?=htmlspecialchars($current_user)?></strong>
            </div>
            
            <p style="background: rgba(239, 68, 68, 0.2); padding: 10px; border-radius: 10px; font-size: 0.9rem;">
                <i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i>
                You don't have permission to access the Server Controller.
            </p>
            
            <a href="dashboard.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ============================================
// OWNER VERIFIED - Continue with server controller
// ============================================

// Get current server status
$server_status = 'online'; // Default
$maintenance_message = '';
$status_result = $conn->query("SELECT * FROM server_settings WHERE setting_key = 'server_status'");
if ($status_result->num_rows > 0) {
    $row = $status_result->fetch_assoc();
    $server_status = $row['setting_value'];
}

$message_result = $conn->query("SELECT * FROM server_settings WHERE setting_key = 'maintenance_message'");
if ($message_result->num_rows > 0) {
    $row = $message_result->fetch_assoc();
    $maintenance_message = $row['setting_value'];
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status'])) {
        $new_status = $_POST['server_status'];
        $new_message = $_POST['maintenance_message'];
        $old_status = $server_status;
        
        // Update server status
        $stmt = $conn->prepare("UPDATE server_settings SET setting_value = ? WHERE setting_key = 'server_status'");
        $stmt->bind_param("s", $new_status);
        $stmt->execute();
        
        if ($stmt->affected_rows == 0) {
            // Insert if not exists
            $stmt = $conn->prepare("INSERT INTO server_settings (setting_key, setting_value) VALUES ('server_status', ?)");
            $stmt->bind_param("s", $new_status);
            $stmt->execute();
        }
        
        // Update maintenance message
        $stmt = $conn->prepare("UPDATE server_settings SET setting_value = ? WHERE setting_key = 'maintenance_message'");
        $stmt->bind_param("s", $new_message);
        $stmt->execute();
        
        if ($stmt->affected_rows == 0) {
            // Insert if not exists
            $stmt = $conn->prepare("INSERT INTO server_settings (setting_key, setting_value) VALUES ('maintenance_message', ?)");
            $stmt->bind_param("s", $new_message);
            $stmt->execute();
        }
        
        // If server is offline/maintenance, block all SDK keys
        if ($new_status == 'offline' || $new_status == 'maintenance') {
            // Block all active licenses
            $conn->query("UPDATE licenses SET status = 0, blocked_by_server = 1, last_blocked_at = NOW() WHERE status = 1");
            
            // Disconnect all devices
            $conn->query("UPDATE devices SET status = 'disconnected' WHERE status = 'connected'");
            
            // Log the action
            error_log("Server set to $new_status mode by $current_user. All licenses blocked and devices disconnected.");
            
        } elseif ($new_status == 'online' && ($old_status == 'offline' || $old_status == 'maintenance')) {
            // If coming back online from offline/maintenance, restore licenses that were blocked by server
            $conn->query("UPDATE licenses SET status = 1, blocked_by_server = 0 WHERE blocked_by_server = 1");
            
            // Log the action
            error_log("Server set to online mode by $current_user. All previously blocked licenses restored.");
        }
        
        $success = "Server status updated successfully!";
        
        // Reload status
        $server_status = $new_status;
        $maintenance_message = $new_message;
    }
    
    if (isset($_POST['test_alert'])) {
        $alert_type = $_POST['alert_type'];
        $alert_message = $_POST['alert_message'];
        
        // Log the alert
        error_log("Alert Sent by $current_user: $alert_type - $alert_message");
        
        // Store in alert history
        $stmt = $conn->prepare("INSERT INTO alert_history (alert_type, message, sent_by) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $alert_type, $alert_message, $current_user);
        $stmt->execute();
        
        $alert_sent = true;
    }
}

// Get connected devices count by package name
$devices_by_package = [];
$tableCheck = $conn->query("SHOW TABLES LIKE 'devices'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $result = $conn->query("SELECT package_name, COUNT(*) as count FROM devices WHERE status = 'connected' GROUP BY package_name");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $devices_by_package[$row['package_name']] = $row['count'];
        }
    }
}

// Get total connected devices
$total_devices = array_sum($devices_by_package);

// Get active licenses count
$active_licenses = 0;
$result = $conn->query("SELECT COUNT(*) as count FROM licenses WHERE status = 1");
if ($result) {
    $row = $result->fetch_assoc();
    $active_licenses = $row['count'];
}

// Get total licenses
$total_licenses = 0;
$result = $conn->query("SELECT COUNT(*) as count FROM licenses");
if ($result) {
    $row = $result->fetch_assoc();
    $total_licenses = $row['count'];
}

// Get blocked by server count
$blocked_by_server = 0;
$result = $conn->query("SELECT COUNT(*) as count FROM licenses WHERE blocked_by_server = 1");
if ($result) {
    $row = $result->fetch_assoc();
    $blocked_by_server = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VBOX • Server Controller</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #020617, #0f172a, #1e3a8a, #312e81);
            background-size: 400% 400%;
            animation: gradient 15s ease infinite;
            min-height: 100vh;
            color: #fff;
            overflow-x: hidden;
        }

        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        #particles-js {
            position: fixed;
            inset: 0;
            z-index: -1;
        }

        /* GLASS EFFECT */
        .glass, .glass-card, .modal-content, .sidebar-btn, header, .status-card, .control-panel, .alert-panel {
            background: rgba(15, 23, 42, 0.7);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 22px;
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.4);
        }

        /* RGB Animation for Headings */
        @keyframes rgbHeading {
            0% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
            17% { color: #ff9933; text-shadow: 0 0 10px #ff8800; }
            33% { color: #ffff33; text-shadow: 0 0 10px #ffff00; }
            50% { color: #33ff33; text-shadow: 0 0 10px #00ff00; }
            67% { color: #33ccff; text-shadow: 0 0 10px #0099ff; }
            83% { color: #9933ff; text-shadow: 0 0 10px #8800ff; }
            100% { color: #ff3333; text-shadow: 0 0 10px #ff0000; }
        }

        .rgb-heading {
            animation: rgbHeading 3s linear infinite;
            font-weight: 700;
        }

        /* HEADER */
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 60px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
            background: rgba(15, 23, 42, 0.8);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 0;
        }

        .menu-btn {
            font-size: 1.5rem;
            cursor: pointer;
            color: #ffd700;
            transition: all 0.3s ease;
        }
        .menu-btn:hover {
            transform: scale(1.1) rotate(90deg);
            color: #22d3ee;
        }

        .user-badge {
            background: rgba(255, 215, 0, 0.15);
            padding: 8px 20px;
            border-radius: 50px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid rgba(255, 215, 0, 0.3);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .user-badge:hover {
            background: rgba(255, 215, 0, 0.25);
            transform: scale(1.05);
            border-color: #ffd700;
        }
        .user-badge i {
            color: #ffd700;
            font-size: 1.1rem;
        }
        .user-badge span {
            font-weight: 600;
            color: #fff;
        }

        /* SIDEBAR */
        #sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            width: 260px;
            height: 100%;
            padding-top: 80px;
            transition: 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1100;
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border-right: 1px solid rgba(255, 255, 255, 0.18);
        }
        #sidebar.active {
            left: 0;
        }

        /* SIDEBAR LOGO */
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
            padding: 0 15px;
        }
        .logo-container {
            width: 100px;
            height: 100px;
            margin: 0 auto 15px;
            position: relative;
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        .logo-glow {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
            border-radius: 50%;
            padding: 3px;
            animation: rotate 4s linear infinite;
        }
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .logo-inner {
            width: 100%;
            height: 100%;
            background: #1a1f2e;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: #ffd700;
            animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(255, 215, 0, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 215, 0, 0); }
        }
        .logo-text {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, #ffd700, #22d3ee, #ffd700);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: rgbText 3s linear infinite;
        }
        @keyframes rgbText {
            0% { filter: hue-rotate(0deg); }
            50% { filter: hue-rotate(180deg); }
            100% { filter: hue-rotate(360deg); }
        }
        .admin-badge {
            background: linear-gradient(135deg, #ffd700, #ffa500);
            color: #000;
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-block;
            margin-top: 5px;
            animation: glow 2s ease-in-out infinite;
        }
        @keyframes glow {
            0% { box-shadow: 0 0 5px #ffd700; }
            50% { box-shadow: 0 0 20px #ffd700; }
            100% { box-shadow: 0 0 5px #ffd700; }
        }

        .sidebar-btn {
            width: 90%;
            margin: 8px auto;
            padding: 12px 16px;
            border-radius: 16px;
            border: none;
            background: rgba(255, 255, 255, 0.08);
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .sidebar-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }
        .sidebar-btn:hover::before {
            left: 100%;
        }
        .sidebar-btn i {
            width: 22px;
            text-align: center;
            color: #ffd700;
            transition: all 0.3s ease;
        }
        .sidebar-btn:hover {
            background: linear-gradient(135deg, #2563eb, #22d3ee);
            transform: translateX(8px);
            box-shadow: 0 5px 15px rgba(37, 99, 235, 0.3);
        }
        .sidebar-btn:hover i {
            color: #fff;
            transform: scale(1.1);
        }

        /* OVERLAY */
        #overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            opacity: 0;
            pointer-events: none;
            transition: 0.3s;
            z-index: 1050;
        }
        #overlay.active {
            opacity: 1;
            pointer-events: auto;
        }

        /* MAIN CONTENT */
        .main {
            padding: 90px 24px 24px;
            max-width: 1400px;
            margin: 0 auto;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Server Status Card */
        .status-card {
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 30px;
        }

        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
        }

        .status-online {
            background: rgba(34, 197, 94, 0.2);
            color: #4ade80;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        .status-online .pulse {
            background: #4ade80;
        }

        .status-offline {
            background: rgba(239, 68, 68, 0.2);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        .status-offline .pulse {
            background: #f87171;
        }

        .status-maintenance {
            background: rgba(234, 179, 8, 0.2);
            color: #facc15;
            border: 1px solid rgba(234, 179, 8, 0.3);
        }
        .status-maintenance .pulse {
            background: #facc15;
        }

        .pulse {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 currentColor; }
            70% { box-shadow: 0 0 0 10px rgba(255,255,255,0); }
            100% { box-shadow: 0 0 0 0 rgba(255,255,255,0); }
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            padding: 25px;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: #ffd700;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: rgba(255, 215, 0, 0.1);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        .stat-icon i {
            font-size: 1.5rem;
            color: #ffd700;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
        }

        /* Devices by Package */
        .package-devices {
            margin-top: 20px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 20px;
        }

        .package-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .package-item:last-child {
            border-bottom: none;
        }
        .package-name {
            font-weight: 600;
            color: #ffd700;
        }
        .package-count {
            background: rgba(255, 215, 0, 0.2);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
        }

        /* Control Panel */
        .control-panel {
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 30px;
        }

        .control-title {
            font-size: 1.3rem;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .control-title i {
            color: #ffd700;
        }

        .status-option {
            padding: 20px;
            border: 2px solid transparent;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            background: rgba(255, 255, 255, 0.02);
        }
        .status-option:hover {
            background: rgba(255, 255, 255, 0.08);
        }
        .status-option.selected {
            border-color: #ffd700;
            background: rgba(255, 215, 0, 0.1);
            transform: scale(1.02);
        }
        .status-option i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .status-option.online i { color: #4ade80; }
        .status-option.offline i { color: #f87171; }
        .status-option.maintenance i { color: #facc15; }

        /* ===== GLASSY BUTTONS ===== */
        .glass-btn {
            padding: 12px 30px;
            border-radius: 50px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }

        .glass-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .glass-btn:hover::before {
            left: 100%;
        }

        .glass-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        }

        .glass-btn:active {
            transform: translateY(0);
        }

        /* Apply Changes Button */
        .btn-apply {
            background: rgba(34, 197, 94, 0.2);
            border: 1px solid rgba(34, 197, 94, 0.4);
            color: #4ade80;
            text-shadow: 0 0 10px rgba(34, 197, 94, 0.5);
        }

        .btn-apply:hover {
            background: rgba(34, 197, 94, 0.3);
            border-color: #4ade80;
            box-shadow: 0 0 20px rgba(34, 197, 94, 0.4);
        }

        /* Emergency Shutdown Button */
        .btn-emergency {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #f87171;
            text-shadow: 0 0 10px rgba(239, 68, 68, 0.5);
            animation: pulse-emergency 2s infinite;
        }

        .btn-emergency:hover {
            background: rgba(239, 68, 68, 0.3);
            border-color: #f87171;
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.4);
            animation: none;
        }

        @keyframes pulse-emergency {
            0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        /* Send Alert Button */
        .btn-alert {
            background: rgba(99, 102, 241, 0.2);
            border: 1px solid rgba(99, 102, 241, 0.4);
            color: #a5b4fc;
            text-shadow: 0 0 10px rgba(99, 102, 241, 0.5);
        }

        .btn-alert:hover {
            background: rgba(99, 102, 241, 0.3);
            border-color: #a5b4fc;
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.4);
        }

        /* Alert Panel */
        .alert-panel {
            padding: 30px;
            border-radius: 30px;
        }

        .alert-types {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .alert-type {
            flex: 1;
            min-width: 100px;
            padding: 15px;
            border-radius: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            background: rgba(255, 255, 255, 0.02);
        }
        .alert-type.info {
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .alert-type.warning {
            border: 1px solid rgba(234, 179, 8, 0.3);
        }
        .alert-type.danger {
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        .alert-type.success {
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        .alert-type.selected {
            transform: scale(1.05);
            background: rgba(255, 255, 255, 0.1);
            border-color: #ffd700;
        }

        .alert-type i {
            font-size: 1.5rem;
            margin-bottom: 8px;
            display: block;
        }
        .alert-type.info i { color: #3b82f6; }
        .alert-type.warning i { color: #eab308; }
        .alert-type.danger i { color: #ef4444; }
        .alert-type.success i { color: #22c55e; }

        /* Form Elements */
        .form-control {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 16px;
            padding: 12px 16px;
        }
        .form-control:focus {
            background: rgba(0, 0, 0, 0.5);
            border-color: #ffd700;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
            color: #fff;
            outline: none;
        }

        /* Alert */
        .alert {
            border-radius: 16px;
            padding: 15px 20px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white;
        }

        /* Warning Banner */
        .warning-banner {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 16px;
            padding: 15px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            animation: blink 2s infinite;
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }

        /* Modal */
        .modal-content {
            background: rgba(15, 23, 42, 0.95) !important;
            border: 1px solid rgba(255, 215, 0, 0.2) !important;
        }
        .modal-header {
            border-bottom: 1px solid rgba(255, 215, 0, 0.2) !important;
        }
        .modal-footer {
            border-top: 1px solid rgba(255, 215, 0, 0.2) !important;
        }

        /* SCROLLBAR */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #ffd700, #22d3ee);
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #22d3ee, #ffd700);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .main {
                padding: 80px 15px 15px;
            }
            .alert-types {
                flex-direction: column;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<!-- Particles -->
<div id="particles-js"></div>

<!-- Header -->
<header>
    <div style="display:flex; align-items:center; gap:15px;">
        <i class="fas fa-bars menu-btn" onclick="toggleSidebar()"></i>
        <h4 class="mb-0 rgb-heading">Online Server Controller</h4>
    </div>
    
    <!-- User Badge -->
    <div class="user-badge">
        <i class="fas fa-user-circle"></i>
        <span><?= htmlspecialchars($current_user) ?></span>
    </div>
</header>

<!-- Overlay -->
<div id="overlay" onclick="toggleSidebar()"></div>

<!-- SIDEBAR WITH LOGO -->
<aside id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-container">
            <div class="logo-glow">
                <div class="logo-inner">
                <!-- Image Logo -->
                <img src="https://i.ibb.co/TD3RcsPg/download-1.png" 
                     style="width:100px; height:100px; border-radius:50%;">
            </div>
        </div>
    </div>

        <div class="logo-text">RSDK VIP PANEL</div>
        <div class="admin-badge">
            <i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($current_user) ?>
        </div>
    </div>

    <button class="sidebar-btn" onclick="location.href='dashboard.php'">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </button>

    <button class="sidebar-btn" onclick="location.href='generate_ui.php'">
        <i class="fas fa-key"></i> Generate License
    </button>

    <button class="sidebar-btn" onclick="location.href='license_list.php'">
        <i class="fas fa-code-branch"></i> List Licenses
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_users.php'">
        <i class="fas fa-circle-user"></i> Manage Users
    </button>

    <button class="sidebar-btn" onclick="location.href='manage_referrals.php'">
        <i class="fas fa-file-pen"></i> Manage Referrals
    </button>

    <button class="sidebar-btn" onclick="location.href='online_server.php'">
        <i class="fas fa-circle-check"></i> Sdk Online Server 
    </button>

    <button class="sidebar-btn" onclick="location.href='settings.php'">
        <i class="fas fa-edit"></i> Settings
    </button>

    <button class="sidebar-btn" onclick="location.href='logout.php'">
        <i class="fas fa-sign-out-alt"></i> Logout
    </button>
</aside>

<!-- Main Content -->
<div class="main">
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i> <?=$success?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($alert_sent)): ?>
        <div class="alert alert-info alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-bell me-2"></i> Alert sent successfully!
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($server_status != 'online'): ?>
        <div class="warning-banner">
            <i class="fas fa-exclamation-triangle fa-2x" style="color: #f87171;"></i>
            <div>
                <strong>⚠️ SERVER IS <?=strtoupper($server_status)?> MODE</strong>
                <p class="mb-0 small opacity-75"><?=htmlspecialchars($maintenance_message ?: 'All SDK keys are currently blocked.')?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Server Status Card -->
    <div class="status-card">
        <h5 class="mb-4 rgb-heading"><i class="fas fa-server me-2" style="color:#ffd700;"></i>Server Status Overview</h5>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-plug"></i>
                </div>
                <div class="stat-value"><?=$total_devices?></div>
                <div class="stat-label">Total Connected Devices</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-key"></i>
                </div>
                <div class="stat-value"><?=$active_licenses?></div>
                <div class="stat-label">Active Licenses</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="stat-value"><?=$total_licenses?></div>
                <div class="stat-label">Total Licenses</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-ban"></i>
                </div>
                <div class="stat-value"><?=$blocked_by_server?></div>
                <div class="stat-label">Blocked by Server</div>
            </div>
        </div>

        <!-- Devices by Package -->
        <?php if (!empty($devices_by_package)): ?>
        <div class="package-devices">
            <h6 class="mb-3 rgb-heading"><i class="fas fa-boxes me-2" style="color:#ffd700;"></i>Connected Devices by Package</h6>
            <?php foreach ($devices_by_package as $package => $count): ?>
            <div class="package-item">
                <span class="package-name"><i class="fas fa-box me-2"></i><?=htmlspecialchars($package)?></span>
                <span class="package-count"><?=$count?> device<?=$count>1?'s':''?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Control Panel -->
    <div class="control-panel">
        <h5 class="control-title rgb-heading">
            <i class="fas fa-sliders-h"></i>
            Server Control Panel
        </h5>

        <form method="post" id="serverForm">
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="status-option online <?=$server_status=='online'?'selected':''?>" onclick="selectStatus('online')">
                        <i class="fas fa-check-circle"></i>
                        <h6>Online Mode</h6>
                        <small class="opacity-50">All services running</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="status-option offline <?=$server_status=='offline'?'selected':''?>" onclick="selectStatus('offline')">
                        <i class="fas fa-times-circle"></i>
                        <h6>Offline Mode</h6>
                        <small class="opacity-50">All services stopped</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="status-option maintenance <?=$server_status=='maintenance'?'selected':''?>" onclick="selectStatus('maintenance')">
                        <i class="fas fa-tools"></i>
                        <h6>Maintenance</h6>
                        <small class="opacity-50">Under maintenance</small>
                    </div>
                </div>
            </div>

            <input type="hidden" name="server_status" id="server_status" value="<?=$server_status?>">
            <input type="hidden" name="update_status" value="1">

            <div class="mb-4">
                <label class="form-label">Maintenance Message</label>
                <textarea class="form-control" name="maintenance_message" rows="3" placeholder="Enter message to display to users..."><?=htmlspecialchars($maintenance_message)?></textarea>
                <small class="opacity-50">This message will be shown to users when server is offline/maintenance</small>
            </div>

            <!-- GLASSY BUTTONS - Control Panel -->
            <div class="d-flex gap-3 flex-wrap">
                <!-- Apply Changes Button -->
                <button type="submit" class="glass-btn btn-apply">
                    <i class="fas fa-save me-2"></i> Apply Changes
                </button>
                
                <!-- Emergency Shutdown Button -->
                <?php if($server_status != 'offline'): ?>
                <button type="button" class="glass-btn btn-emergency" onclick="emergencyShutdown()">
                    <i class="fas fa-exclamation-triangle me-2"></i> Emergency Shutdown
                </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Alert Panel -->
    <div class="alert-panel">
        <h5 class="control-title rgb-heading">
            <i class="fas fa-bell"></i>
            Broadcast Alert
        </h5>

        <form method="post">
            <input type="hidden" name="test_alert" value="1">
            <input type="hidden" name="alert_type" id="alert_type" value="info">

            <div class="alert-types">
                <div class="alert-type info selected" onclick="selectAlertType('info')">
                    <i class="fas fa-info-circle"></i>
                    <span>Info</span>
                </div>
                <div class="alert-type warning" onclick="selectAlertType('warning')">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Warning</span>
                </div>
                <div class="alert-type danger" onclick="selectAlertType('danger')">
                    <i class="fas fa-times-circle"></i>
                    <span>Danger</span>
                </div>
                <div class="alert-type success" onclick="selectAlertType('success')">
                    <i class="fas fa-check-circle"></i>
                    <span>Success</span>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Alert Message</label>
                <input type="text" class="form-control" name="alert_message" placeholder="Enter alert message..." required>
            </div>

            <!-- GLASSY BUTTON - Send Alert -->
            <div class="d-flex gap-3">
                <button type="submit" class="glass-btn btn-alert">
                    <i class="fas fa-paper-plane me-2"></i> Send Alert
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Emergency Shutdown Modal -->
<div class="modal fade" id="emergencyModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content glass">
            <div class="modal-header border-0">
                <h5 class="modal-title rgb-heading"><i class="fas fa-exclamation-triangle text-danger me-2"></i>Emergency Shutdown</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="fw-bold">⚠️ This will immediately:</p>
                <ul class="text-start">
                    <li>Block all active licenses</li>
                    <li>Disconnect all devices</li>
                    <li>Set server to offline mode</li>
                    <li>Prevent new connections</li>
                </ul>
                <p class="text-danger fw-bold mt-3">This action cannot be undone!</p>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="confirmEmergency()">Confirm Shutdown</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>

<script>
// Particles
particlesJS("particles-js", {
    particles: {
        number: { value: 60 },
        color: { value: "#ffffff" },
        opacity: { value: 0.3 },
        size: { value: 2 },
        move: { 
            enable: true,
            speed: 0.8,
            direction: "bottom",
            random: true
        }
    }
});

// Sidebar
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
    document.getElementById('overlay').classList.toggle('active');
}

// Select server status
function selectStatus(status) {
    document.getElementById('server_status').value = status;
    
    document.querySelectorAll('.status-option').forEach(el => {
        el.classList.remove('selected');
    });
    
    document.querySelector(`.status-option.${status}`).classList.add('selected');
}

// Select alert type
function selectAlertType(type) {
    document.getElementById('alert_type').value = type;
    
    document.querySelectorAll('.alert-type').forEach(el => {
        el.classList.remove('selected');
    });
    
    document.querySelector(`.alert-type.${type}`).classList.add('selected');
}

// Emergency shutdown
function emergencyShutdown() {
    new bootstrap.Modal(document.getElementById('emergencyModal')).show();
}

function confirmEmergency() {
    // Set status to offline
    document.getElementById('server_status').value = 'offline';
    
    // Add emergency message
    const messageField = document.querySelector('textarea[name="maintenance_message"]');
    messageField.value = '🚨 EMERGENCY SHUTDOWN - Server is down for immediate maintenance';
    
    // Submit form
    document.getElementById('serverForm').submit();
}

// Show toast notification
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 12px 24px;
        background: ${type === 'success' ? '#10b981' : type === 'danger' ? '#ef4444' : type === 'warning' ? '#eab308' : '#3b82f6'};
        color: white;
        border-radius: 50px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
    `;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>${message}`;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Close overlay
document.getElementById('overlay').onclick = function() {
    document.getElementById('sidebar').classList.remove('active');
    document.getElementById('overlay').classList.remove('active');
};
</script>

</body>
</html>