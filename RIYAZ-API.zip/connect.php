<?php
// connect.php - Handles activation and controller requests

// ========== EARLY EXIT FOR NON-POST / NO MODE ==========
// If it's a GET request or mode is empty → show welcome page immediately (no DB needed)
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['mode'])) {
    showWelcomePage();
    exit;
}

// At this point we have a POST request with a mode → include database
require_once 'conn.php';

header('Content-Type: application/json');

// ========== GET OWNER CONTACT FROM SETTINGS ==========
$ownerContact = '@RIYAZXERO'; // default fallback
if (isset($conn) && $conn) {
    $ownerRes = $conn->query("SELECT setting_value FROM server_settings WHERE setting_key='owner_contact'");
    if ($ownerRes && $row = $ownerRes->fetch_assoc()) {
        $ownerContact = $row['setting_value'];
    }
}

// ========== READ INPUT ==========
$mode = $_POST['mode'];

// ========== ACTIVATION MODE ==========
if ($mode === 'activate') {
    $user_key    = $_POST['user_key'] ?? '';
    $package_name = $_POST['package_name'] ?? '';
    $app_name    = $_POST['app_name'] ?? '';
    $device_id   = $_POST['device_id'] ?? '';

    if (empty($user_key) || empty($package_name)) {
        echo json_encode([
            "status" => "fail",
            "message" => "Missing user_key or package_name. Contact $ownerContact for support."
        ]);
        exit;
    }

    // Look up license
    $stmt = $conn->prepare(
        "SELECT id, expiry_date, daemon, hide_root, hide_xposed, force_logout, controller_interval, toast_message 
         FROM licenses 
         WHERE license_key = ? AND package_name = ? AND status = 1"
    );
    $stmt->bind_param("ss", $user_key, $package_name);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        $license_id = $row['id'];
        $expiry = strtotime($row['expiry_date']);
        $now = time();

        // Check if expired
        if ($expiry < $now) {
            echo json_encode([
                "status" => "fail",
                "message" => "License expired on {$row['expiry_date']}. Contact $ownerContact for renewal."
            ]);
            exit;
        }

        // Record/update device in `devices` table
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $deviceStmt = $conn->prepare(
            "INSERT INTO devices (device_id, package_name, license_key, ip_address, status, last_seen, connected_at) 
             VALUES (?, ?, ?, ?, 'connected', NOW(), NOW())
             ON DUPLICATE KEY UPDATE 
                ip_address = VALUES(ip_address),
                status = 'connected',
                last_seen = NOW(),
                connected_at = IF(status = 'disconnected', NOW(), connected_at)"
        );
        $deviceStmt->bind_param("ssss", $device_id, $package_name, $user_key, $ip);
        $deviceStmt->execute();
        $deviceStmt->close();

        // Update `activated_packages` (optional – track usage)
        $pkgStmt = $conn->prepare(
            "INSERT INTO activated_packages (license_id, package_name, device_id, ip_address, usage_count, last_used) 
             VALUES (?, ?, ?, ?, 1, NOW())
             ON DUPLICATE KEY UPDATE 
                usage_count = usage_count + 1,
                last_used = NOW()"
        );
        $pkgStmt->bind_param("isss", $license_id, $package_name, $device_id, $ip);
        $pkgStmt->execute();
        $pkgStmt->close();

        // Return activation success with controller flags
        echo json_encode([
            "status"       => "success",
            "message"      => "Activation successful",
            "expiry"       => $row['expiry_date'],
            "activated"    => 1,
            "daemon"       => (int)$row['daemon'],
            "hide_root"    => (int)$row['hide_root'],
            "hide_xposed"  => (int)$row['hide_xposed'],
            "force_logout" => (int)$row['force_logout'],
            "interval"     => (int)$row['controller_interval'],
            "toast"        => $row['toast_message']
        ]);
    } else {
        echo json_encode([
            "status"  => "fail",
            "message" => "Invalid license key or package name. Contact $ownerContact for assistance."
        ]);
    }

    $stmt->close();
    $conn->close();
    exit;
}

// ========== CONTROLLER MODE ==========
if ($mode === 'controller') {
    $package_name = $_POST['package_name'] ?? '';
    $device_id    = $_POST['device_id'] ?? '';

    if (empty($package_name) || empty($device_id)) {
        echo json_encode([
            "status"  => "fail",
            "message" => "Missing package_name or device_id. Contact $ownerContact for support."
        ]);
        exit;
    }

    // Find device and join with license to get flags
    $stmt = $conn->prepare(
        "SELECT l.license_key, l.expiry_date, l.daemon, l.hide_root, l.hide_xposed, 
                l.force_logout, l.controller_interval, l.toast_message,
                l.blocked_by_server, d.status as device_status
         FROM devices d
         JOIN licenses l ON l.license_key = d.license_key
         WHERE d.package_name = ? AND d.device_id = ?"
    );
    $stmt->bind_param("ss", $package_name, $device_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        // Check if license expired
        $expiry = strtotime($row['expiry_date']);
        $now = time();
        $activated = ($expiry > $now && $row['device_status'] == 'connected') ? 1 : 0;

        // Check if blocked by server
        $force_logout = ($row['blocked_by_server'] == 1 || $row['force_logout'] == 1) ? 1 : 0;

        // Update last_seen
        $update = $conn->prepare("UPDATE devices SET last_seen = NOW() WHERE device_id = ?");
        $update->bind_param("s", $device_id);
        $update->execute();
        $update->close();

        // If expired, we still return success but with activated=0, and a message
        $message = "Controller update";
        if (!$activated) {
            $message = "License expired on {$row['expiry_date']}. Contact $ownerContact for renewal.";
        }

        echo json_encode([
            "status"       => "success",
            "message"      => $message,
            "activated"    => $activated,
            "daemon"       => (int)$row['daemon'],
            "hide_root"    => (int)$row['hide_root'],
            "hide_xposed"  => (int)$row['hide_xposed'],
            "force_logout" => $force_logout,
            "interval"     => (int)$row['controller_interval'],
            "toast"        => $row['toast_message']
        ]);
    } else {
        // No device/license found
        echo json_encode([
            "status"       => "fail",
            "message"      => "No active license for this device. Contact $ownerContact for help.",
            "activated"    => 0,
            "force_logout" => 1
        ]);
    }

    $stmt->close();
    $conn->close();
    exit;
}

// Unknown mode
echo json_encode([
    "status" => "fail",
    "message" => "Invalid mode. Contact $ownerContact for support."
]);
$conn->close();

// ========== FUNCTION TO SHOW WELCOME PAGE ==========
function showWelcomePage() {
    header('Content-Type: text/html; charset=UTF-8');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Block Box | Premium Gaming Mods</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0b0b1a 0%, #1a1a2e 100%);
            color: #e0e0e0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
            position: relative;
            overflow-x: hidden;
        }

        .blob {
            position: absolute;
            width: 500px;
            height: 500px;
            background: radial-gradient(circle, rgba(255,69,99,0.15) 0%, transparent 70%);
            border-radius: 50%;
            filter: blur(60px);
            z-index: 0;
            animation: float 20s infinite alternate;
        }
        .blob1 { top: -200px; left: -200px; }
        .blob2 { bottom: -200px; right: -200px; background: radial-gradient(circle, rgba(255,44,119,0.15) 0%, transparent 70%); animation-duration: 25s; }

        @keyframes float {
            0% { transform: translate(0, 0) scale(1); }
            100% { transform: translate(100px, 100px) scale(1.2); }
        }

        .container {
            max-width: 1200px;
            width: 100%;
            z-index: 1;
            position: relative;
        }

        .header {
            text-align: center;
            margin-bottom: 3rem;
        }
        .header h1 {
            font-size: 3.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #FF4563, #FF2C77);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 0.5rem;
            animation: fadeInDown 1s ease;
        }
        .header p {
            font-size: 1.2rem;
            color: #b0b0b0;
            max-width: 600px;
            margin: 0 auto;
            animation: fadeInUp 1s ease 0.2s both;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 69, 99, 0.2);
            border-radius: 24px;
            padding: 2rem 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
            cursor: default;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }
        .card:hover {
            transform: translateY(-10px);
            border-color: #FF4563;
            box-shadow: 0 15px 40px rgba(255, 69, 99, 0.2);
        }
        .card i {
            font-size: 3rem;
            background: linear-gradient(135deg, #FF4563, #FF2C77);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
        }
        .card h2 {
            font-size: 1.8rem;
            color: #fff;
            margin-bottom: 0.75rem;
        }
        .card p {
            color: #b0b0b0;
            line-height: 1.6;
            font-size: 1rem;
        }

        .cta {
            text-align: center;
            margin-top: 2rem;
        }
        .btn {
            display: inline-block;
            background: linear-gradient(135deg, #FF4563, #FF2C77);
            color: white;
            padding: 1rem 3rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.2rem;
            letter-spacing: 1px;
            box-shadow: 0 10px 30px -5px rgba(255, 69, 99, 0.4);
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 40px -5px rgba(255, 69, 99, 0.6);
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .header h1 { font-size: 2.5rem; }
            .features { grid-template-columns: 1fr; }
            .card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="blob blob1"></div>
    <div class="blob blob2"></div>

    <div class="container">
        <div class="header">
            <h1>Block Box</h1>
            <p>Experience Gaming at a Whole New Level</p>
        </div>

        <div class="features">
            <div class="card">
                <i class="fas fa-gamepad"></i>
                <h2>Premium Mods</h2>
                <p>Access exclusive gaming modifications with enhanced features.</p>
            </div>
            <div class="card">
                <i class="fas fa-shield-alt"></i>
                <h2>Anti-Ban</h2>
                <p>Advanced protection system to keep your account safe.</p>
            </div>
            <div class="card">
                <i class="fas fa-rocket"></i>
                <h2>Performance</h2>
                <p>Optimized for smooth gameplay without any lag.</p>
            </div>
            <div class="card">
                <i class="fas fa-bolt"></i>
                <h2>Quick Updates</h2>
                <p>Regular updates with new features and improvements.</p>
            </div>
        </div>

        <div class="cta">
            <a href="#" class="btn">Get Started</a>
        </div>
    </div>
</body>
</html>
    <?php
}
?>