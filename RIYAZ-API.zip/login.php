<?php
session_start();
include 'conn.php'; // డేటాబేస్ కనెక్షన్

// లాగిన్ చెయ్ బటన్ క్లిక్ చేసినప్పుడు
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;

    // యూజర్ నేమ్ తో డేటాబేస్ లో వెతకడం
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        // పాస్వర్డ్ వెరిఫై చేయడం
        if (password_verify($password, $user['password'])) {
            // సెషన్ వేరియబుల్స్ సెట్ చేయడం
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['logged_in'] = true;
            
            // రిమెంబర్ మి ఆప్షన్ బట్టి టైమ్ లిమిట్ సెట్ చేయడం
            if ($remember) {
                // 15 నిమిషాలు (15 * 60 సెకండ్లు)
                $_SESSION['login_time'] = time();
                $_SESSION['expiry_time'] = time() + (15 * 60);
                $_SESSION['remember_me'] = true;
            } else {
                // 5 నిమిషాలు
                $_SESSION['login_time'] = time();
                $_SESSION['expiry_time'] = time() + (5 * 60);
                $_SESSION['remember_me'] = false;
            }
            
            // యూజర్ ఆన్‌లైన్ స్టేటస్ అప్‌డేట్ చేయడం
            mysqli_query($conn, "UPDATE users SET is_online=1 WHERE id=" . $user['id']);
            
            // డ్యాష్‌బోర్డ్‌కి రీడైరెక్ట్
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password!";
        }
    } else {
        $error = "Invalid username or password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>RSDK VIP LOGIN | RGB animated title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }

        body {
            background: #000000;
            color: white;
            overflow: hidden;
            height: 100vh;
        }

        #particles-js {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 1;
            background: #000000;
        }

        .page-container {
            position: relative;
            z-index: 10;
            display: flex;
            min-height: 100vh;
            width: 100%;
        }

        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-card {
            width: 440px; /* slightly wider for bigger title */
            padding: 45px 35px;
            background: rgba(0, 0, 0, 0.45);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 50px;
            backdrop-filter: blur(20px) saturate(200%);
            -webkit-backdrop-filter: blur(20px) saturate(200%);
            box-shadow: 0 35px 60px rgba(0, 0, 0, 0.9);
        }

        .logo-container {
            position: relative;
            width: 120px;
            height: 120px;
            margin: 0 auto 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .logo-border {
            position: absolute;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(45deg, #ff416c, #ff4b2b, #f9d423, #56ab2f, #1c92d2);
            background-size: 300% 300%;
            animation: rotateBorder 4s linear infinite;
            box-shadow: 0 0 20px rgba(255,75,43,0.8);
        }

        @keyframes rotateBorder {
            0% { transform: rotate(0deg); background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { transform: rotate(360deg); background-position: 0% 50%; }
        }

        .logo-mask {
            position: absolute;
            width: 108px;
            height: 108px;
            border-radius: 50%;
            background: #000;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .logo-box {
            width: 96px;
            height: 96px;
            border-radius: 50%;
            background: url('https://i.ibb.co/N6K9SJ1R/download.png') center/cover;
            border: 2px solid rgba(255,255,255,0.6);
            z-index: 2;
        }

        /* ===== ANIMATED RGB TITLE ===== */
        .login-title {
            text-align: center;
            font-size: 2.5rem;      /* bigger premium size */
            font-weight: 900;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 8px;
            background: linear-gradient(90deg, #ff416c, #ff4b2b, #f9d423, #56ab2f, #1c92d2, #ff416c);
            background-size: 300% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: rgbFlow 6s linear infinite;
            text-shadow: 0 0 20px rgba(255,75,43,0.5);
        }

        @keyframes rgbFlow {
            0% { background-position: 0% center; }
            100% { background-position: 200% center; }
        }

        .login-sub {
            text-align: center;
            color: #aaa;
            font-size: 1rem;
            margin-bottom: 25px;
            border-bottom: 1px dashed rgba(255,255,255,0.2);
            padding-bottom: 18px;
        }

        .error-message {
            background: rgba(255, 0, 0, 0.2);
            border: 1px solid rgba(255, 0, 0, 0.3);
            color: #ff6b6b;
            padding: 12px;
            border-radius: 30px;
            text-align: center;
            margin-bottom: 20px;
            font-size: 0.9rem;
            backdrop-filter: blur(5px);
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 20px;
            transform: translateY(-50%);
            color: rgba(255,255,255,0.8);
            font-size: 1.2rem;
            z-index: 2;
        }

        .password-wrapper {
            position: relative;
            width: 100%;
        }

        .form-control {
            background: rgba(10, 10, 10, 0.6);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 50px;
            padding-left: 52px;
            padding-right: 50px;
            height: 58px;
            color: white;
            font-size: 1rem;
            backdrop-filter: blur(4px);
            box-shadow: inset 0 5px 10px rgba(0,0,0,0.7);
            transition: 0.2s;
            width: 100%;
        }

        .form-control:focus {
            background: rgba(20, 20, 20, 0.8);
            border-color: #ff4b2b;
            box-shadow: 0 0 15px #ff4b2b, inset 0 2px 8px black;
            outline: none;
        }

        .form-control::placeholder {
            color: #aaa;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 20px;
            transform: translateY(-50%);
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            font-size: 1.3rem;
            z-index: 10;
            background: transparent;
            border: none;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toggle-password:hover {
            color: #ff4b2b;
        }

        .remember-group {
            display: flex;
            align-items: center;
            margin: 15px 0 25px;
            color: #eee;
            position: relative;
            cursor: pointer;
        }

        .remember-group input {
            position: absolute;
            opacity: 0;
            height: 0;
            width: 0;
        }

        .checkmark {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 26px;
            background: rgba(30, 30, 30, 0.8);
            border-radius: 40px;
            border: 1px solid rgba(255,255,255,0.25);
            margin-right: 14px;
            transition: 0.25s;
            box-shadow: inset 0 2px 6px black;
        }

        .checkmark:before {
            content: "";
            position: absolute;
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 2px;
            background: linear-gradient(145deg, #ff416c, #ff4b2b);
            border-radius: 50%;
            transition: 0.25s;
            box-shadow: 0 2px 8px rgba(255,75,43,0.6);
        }

        .remember-group input:checked + .checkmark {
            background: rgba(0, 0, 0, 0.7);
            border-color: #ff4b2b;
        }

        .remember-group input:checked + .checkmark:before {
            transform: translateX(26px);
            background: linear-gradient(145deg, #f9d423, #56ab2f);
            box-shadow: 0 2px 10px #f9d423;
        }

        .remember-text {
            font-size: 1rem;
            font-weight: 500;
            background: linear-gradient(135deg, #ffdde1, #ee9ca7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-login {
            width: 100%;
            padding: 16px;
            border-radius: 60px;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            border: none;
            font-weight: 800;
            font-size: 1.3rem;
            color: white;
            text-shadow: 0 2px 5px black;
            box-shadow: 0 10px 25px rgba(255,75,43,0.4);
            transition: 0.25s;
        }

        .btn-login:hover {
            background: linear-gradient(135deg, #ff4b2b, #ff416c);
            transform: scale(1.02);
            box-shadow: 0 15px 35px #ff4b2b;
        }

        .login-links {
            margin-top: 25px;
            display: flex;
            justify-content: center;
        }

        .login-links a {
            color: #ccc;
            text-decoration: none;
            font-weight: 600;
            padding: 8px 25px;
            border-radius: 40px;
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.15);
            transition: 0.2s;
        }

        .login-links a:hover {
            background: rgba(255,75,43,0.2);
            color: white;
            border-color: #ff4b2b;
        }

        @media(max-width: 480px) {
            .login-card { width: 92%; padding: 30px 20px; }
            .login-title { font-size: 2rem; }
        }
    </style>
</head>
<body>

<div id="particles-js"></div>

<div class="page-container">
    <div class="main-content">
        <div class="login-card">
            <div class="logo-container">
                <div class="logo-border"></div>
                <div class="logo-mask">
                    <div class="logo-box"></div>
                </div>
            </div>
            
            <!-- Animated RGB title -->
            <div class="login-title">𝐑𝐒𝐃𝐊 𝐕𝐈𝐏 𝐋𝐎𝐆𝐈𝐍</div>
            <div class="login-sub">Welcome to Riyaz Premium Panel</div>

            <?php if (isset($error)): ?>
                <div class="error-message">
                    <i class="fa fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <i class="fa fa-user input-icon"></i>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>

                <div class="form-group">
                    <i class="fa fa-lock input-icon"></i>
                    <div class="password-wrapper">
                        <input type="password" name="password" id="passwordField" class="form-control" placeholder="Password" required>
                        <i class="fa fa-eye toggle-password" id="togglePassword" onclick="togglePassword()"></i>
                    </div>
                </div>

                <label class="remember-group">
                    <input type="checkbox" name="remember" id="rememberCheck">
                    <span class="checkmark"></span>
                    <span class="remember-text"><i class="fa-regular fa-clock"></i> Remember me</span>
                </label>

                <button type="submit" name="login" class="btn-login">
                    <i class="fa fa-right-to-bracket"></i> LOGIN
                </button>

                <div class="login-links">
                    <a href="register.php"><i class="fa fa-user-plus"></i> Register</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- dashboard.php కోసం ఆటో లాగౌట్ చెక్ (ఈ కోడ్‌ను dashboard.php లో వేయండి) -->
<?php
// ఈ కోడ్‌ను dashboard.php ఫైల్ లో top లో వేయండి
/*
<?php
session_start();
include 'conn.php';

// చెక్ చేయడం యూజర్ లాగిన్ అయ్యాడా లేదా
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

// ఆటో లాగౌట్ టైమ్ చెక్ చేయడం
if (isset($_SESSION['expiry_time']) && time() > $_SESSION['expiry_time']) {
    // సెషన్ టైమ్ అయిపోయింది - లాగౌట్ చేయించడం
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// టైమ్ రిఫ్రెష్ చేయడం (ఐచ్ఛికం)
// $_SESSION['expiry_time'] = time() + (15 * 60); // రిమెంబర్ మి కోసం
// లేదా
// $_SESSION['expiry_time'] = time() + (5 * 60); // నార్మల్ లాగిన్ కోసం
?>
*/
?>

<script>
    particlesJS('particles-js', {
        particles: {
            number: { value: 100, density: { enable: true, value_area: 1000 } },
            color: { value: ["#ff416c", "#ff4b2b", "#f9d423", "#56ab2f", "#1c92d2"] },
            shape: { type: ["circle", "triangle"] },
            opacity: { value: 0.6, random: true },
            size: { value: 4, random: true },
            line_linked: { enable: true, distance: 140, color: "#ffffff", opacity: 0.15 },
            move: { enable: true, speed: 2 }
        },
        interactivity: {
            events: { onhover: { enable: true, mode: "grab" } }
        }
    });

    function togglePassword() {
        const passwordField = document.getElementById('passwordField');
        const toggleIcon = document.getElementById('togglePassword');
        
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }
</script>

</body>
</html>