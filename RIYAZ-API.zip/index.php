<?php
session_start();
include 'login.php';
if (!empty($_SESSION['is_logged_in'])){
$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));
} else 
if (!empty($_COOKIE['is_logged_in'])){

$login = $_COOKIE['is_logged_in'];

$_SESSION['is_logged_in'] = $login;

$login_data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM panel WHERE _username = '".$_SESSION['is_logged_in']."'"));

}
$fetch_server = mysqli_query($con, "SELECT * FROM server WHERE srv_id = '1'");
$server_data = mysqli_fetch_assoc($fetch_server);
?>
<!DOCTYPE html>

